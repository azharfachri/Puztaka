<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Tambah Anggota | Perpustakaan</title>

    <link rel="stylesheet" href="<?= base_url('aset/css/dashboard.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('aset/css/anggota.css'); ?>">
    <link rel="stylesheet" href="<?= base_url('aset/css/tambah_anggota.css'); ?>">
</head>

<body>

<div class="dashboard-wrapper">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <div>

            <div class="sidebar-brand">

                <div class="sidebar-logo">
                    <img src="<?= base_url('aset/img/logo_perpustakaan.png'); ?>" alt="Logo Perpustakaan">
                </div>

                <h2>Perpustakaan</h2>
                <p>Sistem Informasi</p>

            </div>

            <nav class="sidebar-menu">

                <a href="<?= base_url('index.php/dashboard'); ?>">
    <span class="menu-icon">⌂</span>
    <span>Dashboard</span>
</a>

<a href="<?= base_url('index.php/anggota'); ?>" class="active">
    <span class="menu-icon">👥</span>
    <span>Data Anggota</span>
</a>

<a href="<?= base_url('index.php/buku'); ?>">
    <span class="menu-icon">📚</span>
    <span>Data Buku</span>
</a>

<a href="<?= base_url('index.php/kategori'); ?>">
    <span class="menu-icon">🏷️</span>
    <span>Kategori</span>
</a>

<a href="<?= base_url('index.php/peminjaman'); ?>">
    <span class="menu-icon">📖</span>
    <span>Peminjaman</span>
</a>
            </nav>

        </div>

        <div class="sidebar-logout">
            <a href="<?= base_url('index.php/login/logout'); ?>">
                <span>↪</span>
                <span>Keluar</span>
            </a>
        </div>

    </aside>

    <!-- MAIN -->

    <main class="main-content">

        <div class="topbar">

            <div class="topbar-title">
                <h1>Tambah Anggota</h1>
                <p>Tambahkan anggota baru ke dalam sistem.</p>
            </div>

            <div class="admin-profile">
                <div class="admin-name">
                    <?= $this->session->userdata('nama_petugas'); ?> - Administrator
                </div>
            </div>

        </div>

        <div class="content-card tambah-card">

            <div class="card-header">

                <div>
                    <h3>Form Data Anggota</h3>
                    <span>Lengkapi data anggota dengan benar.</span>
                </div>

                <div class="header-badge">
                    Anggota Baru
                </div>

            </div>

            <div class="form-container">

                <form action="<?= base_url('index.php/anggota/tambah_aksi'); ?>" method="POST">

                    <div class="form-grid">

                        <div class="form-group">
                            <label>ID Anggota</label>

                            <div class="input-box">
                                <span>🆔</span>

                                <input
                                    type="text"
                                    name="id_anggota"
                                    placeholder="Contoh: 262710450"
                                    required
                                >
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Nama</label>

                            <div class="input-box">
                                <span>👤</span>

                                <input
                                    type="text"
                                    name="nama"
                                    placeholder="Masukkan nama anggota"
                                    required
                                >
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Kelas</label>

                            <div class="input-box">
                                <span>🏫</span>

                                <input
                                    type="text"
                                    name="kelas"
                                    placeholder="Contoh: XI PPLG 3"
                                    required
                                >
                            </div>
                        </div>

                        <div class="form-group full">
                            <label>Alamat</label>

                            <div class="input-box">
                                <span>📍</span>

                                <input
                                    type="text"
                                    name="alamat"
                                    placeholder="Masukkan alamat lengkap"
                                    required
                                >
                            </div>
                        </div>

                    </div>

                    <div class="form-actions">

                        <a href="<?= base_url('index.php/anggota'); ?>" class="btn-cancel">
                            ← Batal
                        </a>

                        <button type="submit" class="btn-save">
                            + Simpan Anggota
                        </button>

                    </div>

                </form>

            </div>

        </div>

    </main>

</div>

</body>
</html>