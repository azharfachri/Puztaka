<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Dashboard | Sistem Informasi Perpustakaan</title>

    <link rel="stylesheet"
          href="<?= base_url('aset/css/dashboard.css'); ?>">

</head>

<body>

<div class="dashboard-wrapper">


    <!-- SIDEBAR -->

    <aside class="sidebar">

        <div>

            <div class="sidebar-brand">

                <div class="sidebar-logo">

                    <img
    src="<?= base_url('aset/img/logo_perpustakaan.png'); ?>"
    alt="Logo Perpustakaan"
>

                </div>

                <h2>Perpustakaan</h2>

                <p>Sistem Informasi</p>

            </div>


            <nav class="sidebar-menu">

    <a href="<?= base_url('index.php/dashboard'); ?>" class="active">
        <span class="menu-icon">⌂</span>
        <span>Dashboard</span>
    </a>

    <a href="<?= base_url('index.php/anggota'); ?>">
        <span class="menu-icon">👥</span>
        <span>Data Anggota</span>
    </a>

    <a href="<?= base_url('index.php/buku'); ?>">
        <span class="menu-icon">📚</span>
        <span>Data Buku</span>
    </a>

    <a href="<?= base_url('index.php/kategori'); ?>">
        <span class="menu-icon">🏷️</span>
        <span>Kategori</span>
    </a>

    <a href="<?= base_url('index.php/peminjaman'); ?>">
        <span class="menu-icon">📖</span>
        <span>Peminjaman</span>
    </a>

</nav>

        </div>


        <!-- LOGOUT -->

        <<div class="sidebar-logout">
            <a href="<?= base_url('index.php/login/logout'); ?>">
                ↪ Keluar
            </a>
        </div>

    </aside>



    <!-- MAIN CONTENT -->

    <main class="main-content">


        <!-- TOPBAR -->

        <div class="topbar">

            <div class="topbar-title">

                <h1>Dashboard</h1>

                <p>
                    Ringkasan sistem perpustakaan
                </p>

            </div>


            <div class="admin-profile">

                <div class="admin-avatar">

                    <?= strtoupper(
                        substr(
                            $this->session->userdata('nama_petugas'),
                            0,
                            1
                        )
                    ); ?>

                </div>


                <div>

                    <div class="admin-name">

                        <?= $this->session->userdata('nama_petugas'); ?>

                    </div>

                    <div class="admin-role">
                        Administrator
                    </div>

                </div>

            </div>

        </div>



        <!-- WELCOME -->

        <div class="welcome-card">

    <div class="welcome-content">

        <h2 class="welcome-greeting">
            hallo...
        </h2>

        <div class="welcome-name">
            <?= $this->session->userdata('nama_petugas'); ?>!
        </div>

        <p>
            Kelola data perpustakaan dengan mudah
            melalui dashboard ini.
        </p>

    </div>

</div>



        <!-- STATISTICS -->

        <div class="stats-grid">


            <div class="stat-card">

                <div class="stat-icon icon-blue">
                    👥
                </div>

                <div class="stat-info">

                    <span>Total Anggota</span>

                    <strong>
                        <?= $total_anggota; ?>
                    </strong>

                </div>

            </div>



            <div class="stat-card">

                <div class="stat-icon icon-coral">
                    📚
                </div>

                <div class="stat-info">

                    <span>Total Buku</span>

                    <strong>
                        <?= $total_buku; ?>
                    </strong>

                </div>

            </div>



            <div class="stat-card">

                <div class="stat-icon icon-teal">
                    📖
                </div>

                <div class="stat-info">

                    <span>Peminjaman</span>

                    <strong>
                        <?= $total_peminjaman; ?>
                    </strong>

                </div>

            </div>



            <div class="stat-card">

                <div class="stat-icon icon-yellow">
                    ⚠️
                </div>

                <div class="stat-info">

                    <span>Terlambat</span>

                    <strong>
                        <?= $total_terlambat; ?>
                    </strong>

                </div>

            </div>


        </div>



        <!-- PEMINJAMAN TERBARU -->

        <div class="content-card">

            <div class="card-header">

                <h3>
                    Peminjaman Terbaru
                </h3>

                <span>
                    Data terbaru
                </span>

            </div>


            <div class="table-wrapper">

                <table>

                    <thead>

                        <tr>

                            <th>ID</th>

                            <th>Anggota</th>

                            <th>Buku</th>

                            <th>Tanggal Pinjam</th>

                            <th>Status</th>

                        </tr>

                    </thead>


                    <tbody>

<?php if(!empty($peminjaman_terbaru)): ?>

<?php foreach($peminjaman_terbaru as $p): ?>

<?php

if(empty($p->tanggal_kembali)){

    if(strtotime($p->tanggal_jatuh_tempo)<strtotime(date('Y-m-d'))){

        $status="Terlambat";

        $class="status-terlambat";

    }else{

        $status="Dipinjam";

        $class="status-dipinjam";

    }

}else{

    $status="Dikembalikan";

    $class="status-tepat";

}

?>

<tr>

<td><?= $p->id_pinjam;?></td>

<td><?= $p->nama;?></td>

<td><?= $p->judul_buku;?></td>

<td><?= date('d-m-Y',strtotime($p->tanggal_pinjam));?></td>

<td>

<span class="status <?= $class;?>">

<?= $status;?>

</span>

</td>

</tr>

<?php endforeach;?>

<?php else:?>

<tr>

<td colspan="5" style="text-align:center;padding:24px;color:#6b7280;">

Belum ada data peminjaman 3 hari terakhir.

</td>

</tr>

<?php endif;?>

</tbody>
                </table>

            </div>

        </div>


    </main>

</div>

</body>

</html>