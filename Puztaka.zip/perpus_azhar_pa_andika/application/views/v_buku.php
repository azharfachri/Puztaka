<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Data Buku | Perpustakaan</title>

    <link rel="stylesheet"
          href="<?= base_url('aset/css/anggota.css'); ?>">

</head>

<body>

<div class="dashboard-wrapper">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <div>

            <div class="sidebar-brand">

                <div class="sidebar-logo">

                    <img
                        src="<?= base_url('aset/img/logo_perpustakaan.png'); ?>"
                        alt="Logo Perpustakaan"
                    >

                </div>

                <h2>Perpustakaan</h2>

                <p>Sistem Informasi</p>

            </div>


            <nav class="sidebar-menu">

                <a href="<?= base_url('index.php/dashboard'); ?>">
                    <span class="menu-icon">⌂</span>
                    <span>Dashboard</span>
                </a>

                <a href="<?= base_url('index.php/anggota'); ?>">
                    <span class="menu-icon">👥</span>
                    <span>Data Anggota</span>
                </a>

                <a href="<?= base_url('index.php/buku'); ?>" class="active">
                    <span class="menu-icon">📚</span>
                    <span>Data Buku</span>
                </a>

                <a href="<?= base_url('index.php/kategori'); ?>">
                    <span class="menu-icon">🏷️</span>
                    <span>Kategori</span>
                </a>

                <a href="<?= base_url('index.php/peminjaman'); ?>">
                    <span class="menu-icon">📖</span>
                    <span>Peminjaman</span>
                </a>

            </nav>

        </div>


        <!-- LOGOUT -->

        <div class="sidebar-logout">

            <a href="<?= base_url('index.php/login/logout'); ?>">
                ↪ Keluar
            </a>

        </div>

    </aside>


    <!-- MAIN -->

    <main class="main-content">


        <!-- TOPBAR -->

        <div class="topbar">

            <div class="topbar-title">

                <h1>Data Buku</h1>

                <p>
                    Kelola data buku perpustakaan
                </p>

            </div>


            <div class="admin-profile">

                <div class="admin-name">

                    <?= $this->session->userdata('nama_petugas'); ?>
                    - Administrator

                </div>

            </div>

        </div>


        <!-- CONTENT -->

        <div class="content-card">


            <!-- HEADER -->

            <div class="card-header">

                <div>

                    <h3>Daftar Buku</h3>

                    <span>
                        Data seluruh buku perpustakaan
                    </span>

                </div>


                <a
                    href="<?= base_url('index.php/buku/tambah'); ?>"
                    class="btn-add"
                >

                    + Tambah Buku

                </a>

            </div>


            <!-- FILTER -->

            <form class="filter-form">

                <div class="filter-search">

                    <span>🔍</span>

                    <input
                        type="text"
                        id="searchBuku"
                        placeholder="Cari ID buku, judul, pengarang, atau kategori..."
                    >

                </div>


                <select id="filterKategori">

                    <option value="">
                        Semua Kategori
                    </option>

                    <?php foreach ($kategori_list as $k): ?>

                        <option value="<?= strtolower($k->id_kategori); ?>">

                            <?= $k->id_kategori; ?>
                            -
                            <?= $k->nama_kategori; ?>

                        </option>

                    <?php endforeach; ?>

                </select>


                <button
                    type="button"
                    class="btn-reset"
                    id="resetFilter"
                >
                    Reset
                </button>

            </form>


            <!-- TABLE -->

            <div class="table-wrapper">

                <table id="tabelBuku">

                    <thead>

                        <tr>

                            <th>No</th>

                            <th>ID Buku</th>

                            <th>Judul</th>

                            <th>Pengarang</th>

                            <th>Tahun</th>

                            <th>Kategori</th>

                            <th>Stok</th>

                            <th>Aksi</th>

                        </tr>

                    </thead>


                    <tbody>

                    <?php $no = 1; ?>

                    <?php foreach ($buku as $data): ?>

                        <tr
                            data-id="<?= strtolower($data->id_buku); ?>"
                            data-judul="<?= strtolower($data->judul); ?>"
                            data-pengarang="<?= strtolower($data->pengarang); ?>"
                            data-kategori="<?= strtolower($data->id_kategori); ?>"
                            data-kategorinama="<?= strtolower($data->nama_kategori ?? $data->id_kategori); ?>"
                        >

                            <td>
                                <?= $no++; ?>
                            </td>


                            <td>
                                <?= $data->id_buku; ?>
                            </td>


                            <td>
                                <?= $data->judul; ?>
                            </td>


                            <td>
                                <?= $data->pengarang; ?>
                            </td>


                            <td>
                                <?= $data->tahun; ?>
                            </td>


                            <td>
                                <?= $data->id_kategori; ?>
                            </td>


                            <td>

                                <span class="stok-badge">

                                    <?= $data->stok; ?>

                                </span>

                            </td>


                            <td class="action-buttons">

                                <a
                                    href="<?= base_url('index.php/buku/edit/'.$data->id_buku); ?>"
                                    class="btn-action btn-edit"
                                >

                                    Edit

                                </a>


                                <a
                                    href="<?= base_url('index.php/buku/hapus/'.$data->id_buku); ?>"
                                    class="btn-action btn-delete"
                                    onclick="return confirm('Yakin ingin menghapus buku ini?');"
                                >

                                    Hapus

                                </a>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </main>

</div>


<!-- SWEETALERT -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<?php if ($this->session->flashdata('success')): ?>

<script>

Swal.fire({

    toast: true,

    position: 'top-end',

    icon: 'success',

    title: '<?= $this->session->flashdata('success'); ?>',

    showConfirmButton: false,

    timer: 3000,

    timerProgressBar: true

});

</script>

<?php endif; ?>


<?php if ($this->session->flashdata('error')): ?>

<script>

Swal.fire({

    toast: true,

    position: 'top-end',

    icon: 'error',

    title: '<?= $this->session->flashdata('error'); ?>',

    showConfirmButton: false,

    timer: 3000,

    timerProgressBar: true

});

</script>

<?php endif; ?>


<script src="<?= base_url('aset/js/buku.js'); ?>"></script>

</body>

</html>