<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Data Peminjaman</title>

<link rel="stylesheet" href="<?= base_url('aset/css/dashboard.css'); ?>">
<link rel="stylesheet" href="<?= base_url('aset/css/anggota.css'); ?>">
<link rel="stylesheet" href="<?= base_url('aset/css/peminjaman.css'); ?>">

</head>

<body>

<div class="dashboard-wrapper">

    <!-- SIDEBAR -->
    <aside class="sidebar">

        <div>

            <div class="sidebar-brand">

                <div class="sidebar-logo">
                    <img src="<?= base_url('aset/img/logo_perpustakaan.png'); ?>" alt="Logo">
                </div>

                <h2>Perpustakaan</h2>
                <p>Sistem Informasi</p>

            </div>

            <nav class="sidebar-menu">

                <a href="<?= base_url('index.php/dashboard'); ?>">
                    <span class="menu-icon">⌂</span>
                    <span>Dashboard</span>
                </a>

                <a href="<?= base_url('index.php/anggota'); ?>">
                    <span class="menu-icon">👥</span>
                    <span>Data Anggota</span>
                </a>

                <a href="<?= base_url('index.php/buku'); ?>">
                    <span class="menu-icon">📚</span>
                    <span>Data Buku</span>
                </a>

                <a href="<?= base_url('index.php/kategori'); ?>">
                    <span class="menu-icon">🏷️</span>
                    <span>Kategori</span>
                </a>

                <a href="<?= base_url('index.php/peminjaman'); ?>" class="active">
                    <span class="menu-icon">📖</span>
                    <span>Peminjaman</span>
                </a>

            </nav>

        </div>

        <div class="sidebar-logout">
            <a href="<?= base_url('index.php/login/logout'); ?>">
                ↪ Keluar
            </a>
        </div>

    </aside>

    <!-- MAIN -->
    <main class="main-content">

        <div class="topbar">

            <div class="topbar-title">

                <h1>Data Peminjaman</h1>
                <p>Kelola transaksi peminjaman buku.</p>

            </div>

            <div class="admin-profile">

                <div class="admin-name">

                    <?= $this->session->userdata('nama_petugas'); ?>

                    - Administrator

                </div>

            </div>

        </div>

        <div class="content-card">

            <div class="card-header">

                <div>

                    <h3>Daftar Peminjaman</h3>
                    <span>Data seluruh transaksi peminjaman buku</span>

                </div>

                <a href="<?= base_url('index.php/peminjaman/tambah'); ?>"
                   class="btn-add">

                    + Tambah Peminjaman

                </a>

            </div>

            <!-- FILTER -->
            <div class="filter-bar">

    <div class="filter-search">
        🔍
        <input
            id="searchPinjam"
            placeholder="Cari ID Pinjam, ID Anggota, anggota atau buku...">
    </div>

    <select id="filterStatus" class="filter-select">
        <option value="">Semua Status</option>
        <option value="dipinjam">Dipinjam</option>
        <option value="dikembalikan">Dikembalikan</option>
        <option value="terlambat">Terlambat</option>
    </select>

</div>

<!-- Spacer -->
<div class="table-gap"></div>

<div class="table-container">
    <div class="table-wrapper">
        <table>

                    <thead>

                        <tr>

                            <th>No</th>
<th>ID Pinjam</th>
<th>ID Anggota</th>
<th>Anggota</th>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Estimasi</th>
                            <th>Dikembalikan</th>
                            <th>Status</th>
                            <th>Aksi</th>

                        </tr>

                    </thead>

                    <tbody>

                    <?php $no = 1; ?>

                    <?php foreach($peminjaman as $p): ?>

                    <?php

                    if(empty($p->tanggal_kembali)){

                        if(strtotime($p->tanggal_jatuh_tempo) < strtotime(date('Y-m-d'))){

                            $status="Terlambat";

                        }else{

                            $status="Dipinjam";

                        }

                    }else{

                        if($p->keterangan=="Terlambat"){

                            $status="Terlambat";

                        }else{

                            $status="Dikembalikan";

                        }

                    }

                    ?>

                    <tr class="pinjam-row"

data-pinjam="<?= strtolower($p->id_pinjam); ?>"

data-id="<?= strtolower($p->id_anggota); ?>"

data-anggota="<?= strtolower($p->nama); ?>"

data-buku="<?= strtolower($p->judul); ?>"

data-status="<?= strtolower($status); ?>">

                        <td><?= $no++; ?></td>

<td class="id-pinjam"><?= $p->id_pinjam; ?></td>

<td class="id-anggota"><?= $p->id_anggota; ?></td>

<td><?= $p->nama; ?></td>
                        <td><?= $p->judul; ?></td>

                        <td><?= date('d-m-Y',strtotime($p->tanggal_pinjam)); ?></td>

                        <td><?= date('d-m-Y',strtotime($p->tanggal_jatuh_tempo)); ?></td>

                        <td>

                        <?= empty($p->tanggal_kembali)

                        ? '-'

                        : date('d-m-Y',strtotime($p->tanggal_kembali)); ?>

                        </td>

                        <td>

                            <span class="status-badge

                            <?= strtolower($status)=='terlambat'

                            ?'status-terlambat'

                            :(strtolower($status)=='dipinjam'

                            ?'status-dipinjam'

                            :'status-kembali');?>">

                            <?= $status; ?>

                            </span>

                        </td>

                        <td class="action-buttons">

                            <a href="<?= base_url('index.php/peminjaman/edit/'.$p->id_pinjam); ?>"

                               class="btn-action btn-edit">

                                Edit

                            </a>

                            <a href="<?= base_url('index.php/peminjaman/hapus/'.$p->id_pinjam); ?>"

                               class="btn-action btn-delete btn-hapus"

                               onclick="return confirm('Yakin ingin menghapus data peminjaman ini?');">

                                Hapus

                            </a>

                        </td>

                    </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        </div>

    </main>

</div>

<!-- SCRIPT FILTER -->
<script>

const search=document.getElementById("searchPinjam");

const filter=document.getElementById("filterStatus");

const rows=document.querySelectorAll(".pinjam-row");

function filterData(){

const keyword=search.value.toLowerCase();

const status=filter.value.toLowerCase();

rows.forEach(row=>{

const cocokKeyword=

row.dataset.id.includes(keyword)

||row.dataset.anggota.includes(keyword)

||row.dataset.buku.includes(keyword);

const cocokStatus=

status===""

||row.dataset.status===status;

row.style.display=cocokKeyword&&cocokStatus?"":"none";

});

}

search.addEventListener("input",filterData);

filter.addEventListener("change",filterData);

</script>

<!-- SWEETALERT -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if($this->session->flashdata('success')): ?>

<script>

Swal.fire({

toast:true,

position:'top-end',

icon:'success',

title:'<?= $this->session->flashdata('success'); ?>',

showConfirmButton:false,

timer:3000,

timerProgressBar:true

});

</script>

<?php endif; ?>

<?php if($this->session->flashdata('error')): ?>

<script>

Swal.fire({

toast:true,

position:'top-end',

icon:'error',

title:'<?= $this->session->flashdata('error'); ?>',

showConfirmButton:false,

timer:3500,

timerProgressBar:true

});

</script>

<?php endif; ?>

</body>
</html>