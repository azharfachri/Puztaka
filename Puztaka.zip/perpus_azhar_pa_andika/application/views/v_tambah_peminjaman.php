<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Tambah Peminjaman</title>

<link rel="stylesheet" href="<?= base_url('aset/css/dashboard.css');?>">
<link rel="stylesheet" href="<?= base_url('aset/css/anggota.css');?>">
<link rel="stylesheet" href="<?= base_url('aset/css/tambah_anggota.css');?>">
<link rel="stylesheet" href="<?= base_url('aset/css/peminjaman.css');?>">

<!-- Tom Select -->
<link href="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/css/tom-select.css" rel="stylesheet">

<style>
.select-search-box{
    width:100%;
}

.ts-wrapper{
    width:100%;
}

.ts-control{
    width:100%;
    min-height:48px;
    padding:10px 14px;
    border:2px solid #e5e7eb !important;
    border-radius:12px;
    font-family:Poppins,sans-serif;
    box-shadow:none !important;
}

.ts-wrapper.focus .ts-control{
    border-color:#23308b !important;
    box-shadow:0 0 0 4px rgba(35,48,139,.08) !important;
}

.ts-dropdown{
    border:2px solid #e5e7eb;
    border-radius:12px;
    margin-top:6px;
    font-family:Poppins,sans-serif;
}

.ts-dropdown .option{
    padding:12px;
}
</style>

</head>

<body>

<div class="dashboard-wrapper">

<aside class="sidebar">

<div>

<div class="sidebar-brand">

<div class="sidebar-logo">

<img src="<?= base_url('aset/img/logo_perpustakaan.png');?>">

</div>

<h2>Perpustakaan</h2>
<p>Sistem Informasi</p>

</div>

<nav class="sidebar-menu">

<a href="<?= base_url('index.php/dashboard');?>"><span class="menu-icon">⌂</span><span>Dashboard</span></a>

<a href="<?= base_url('index.php/anggota');?>"><span class="menu-icon">👥</span><span>Data Anggota</span></a>

<a href="<?= base_url('index.php/buku');?>"><span class="menu-icon">📚</span><span>Data Buku</span></a>

<a href="<?= base_url('index.php/kategori');?>"><span class="menu-icon">🏷️</span><span>Kategori</span></a>

<a href="<?= base_url('index.php/peminjaman');?>" class="active"><span class="menu-icon">📖</span><span>Peminjaman</span></a>

</nav>

</div>

<div class="sidebar-logout">
<a href="<?= base_url('index.php/login/logout');?>">↪ Keluar</a>
</div>

</aside>

<main class="main-content">

<div class="topbar">

<div class="topbar-title">
<h1>Tambah Peminjaman</h1>
<p>Tambahkan transaksi peminjaman baru.</p>
</div>

<div class="admin-profile">
<div class="admin-name">
<?= $this->session->userdata('nama_petugas');?> - Administrator
</div>
</div>

</div>

<div class="content-card tambah-card">

<div class="card-header">

<div>
<h3>Form Peminjaman</h3>
<span>Lengkapi data peminjaman.</span>
</div>

<div class="header-badge">
Peminjaman Baru
</div>

</div>

<div class="form-container">

<form action="<?= base_url('index.php/peminjaman/tambah_aksi');?>" method="POST">

<div class="form-grid">

<!-- =========================
     ANGGOTA
========================= -->

<div class="form-group">

<label>Anggota</label>

<div class="select-search-box">
    <select id="anggotaSelect" name="id_anggota" required>
        <option value="">Cari ID atau nama anggota...</option>

        <?php foreach($anggota as $a): ?>
        <option value="<?= $a->id_anggota; ?>">
            <?= $a->id_anggota; ?> - <?= $a->nama; ?>
        </option>
        <?php endforeach; ?>

    </select>
</div>

</div>

<!-- =========================
     BUKU
========================= -->

<div class="form-group">

<label>Buku</label>

<div class="select-search-box">
    <select id="bukuSelect" name="id_buku" required>
        <option value="">Cari ID atau judul buku...</option>

        <?php foreach($buku as $b): ?>
        <option value="<?= $b->id_buku; ?>">
            <?= $b->id_buku; ?> - <?= $b->judul; ?>
        </option>
        <?php endforeach; ?>

    </select>
</div>

</div>

<!-- =========================
     TANGGAL PINJAM
========================= -->

<div class="form-group">

<label>Tanggal Pinjam</label>

<div class="input-box">

<span>📅</span>

<input
id="tanggal_pinjam"
type="date"
name="tanggal_pinjam"
value="<?= date('Y-m-d');?>"
required>

</div>

</div>

<!-- =========================
     ESTIMASI
========================= -->

<div class="form-group">

<label>Estimasi Kembali (Otomatis)</label>

<div class="input-box">

<span>⏳</span>

<input
id="tanggal_jatuh_tempo"
type="date"
readonly>

</div>

</div>

</div>

<div class="form-actions">

<a href="<?= base_url('index.php/peminjaman');?>" class="btn-cancel">

← Batal

</a>

<button type="submit" class="btn-save">

+ Simpan Peminjaman

</button>

</div>

</form>

</div>

</div>

</main>

</div>

<!-- Tom Select -->
<script src="https://cdn.jsdelivr.net/npm/tom-select@2.3.1/dist/js/tom-select.complete.min.js"></script>

<script>
// =========================
// LIVE SEARCH ANGGOTA
// =========================
new TomSelect("#anggotaSelect",{
    create:false,
    maxItems:1,
    closeAfterSelect:true,
    hideSelected:true,
    placeholder:"Cari ID atau nama anggota..."
});

new TomSelect("#bukuSelect",{
    create:false,
    maxItems:1,
    closeAfterSelect:true,
    hideSelected:true,
    placeholder:"Cari ID atau judul buku..."
});

// =========================
// ESTIMASI 5 HARI
// =========================
const pinjam=document.getElementById("tanggal_pinjam");
const tempo=document.getElementById("tanggal_jatuh_tempo");

function hitungTempo(){

    if(!pinjam.value) return;

    let t=new Date(pinjam.value);

    t.setDate(t.getDate()+5);

    tempo.value=t.toISOString().split("T")[0];

}

hitungTempo();

pinjam.addEventListener("change",hitungTempo);
</script>

</body>
</html>