<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Tambah Buku | Perpustakaan</title>

    <link rel="stylesheet"
          href="<?= base_url('aset/css/dashboard.css'); ?>">

    <link rel="stylesheet"
          href="<?= base_url('aset/css/anggota.css'); ?>">

    <link rel="stylesheet"
          href="<?= base_url('aset/css/tambah_anggota.css'); ?>">

</head>

<body>

<div class="dashboard-wrapper">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <div>

            <div class="sidebar-brand">

                <div class="sidebar-logo">

                    <img
                        src="<?= base_url('aset/img/logo_perpustakaan.png'); ?>"
                        alt="Logo Perpustakaan"
                    >

                </div>

                <h2>Perpustakaan</h2>

                <p>Sistem Informasi</p>

            </div>


            <nav class="sidebar-menu">

                <a href="<?= base_url('index.php/dashboard'); ?>">
                    <span class="menu-icon">⌂</span>
                    <span>Dashboard</span>
                </a>

                <a href="<?= base_url('index.php/anggota'); ?>">
                    <span class="menu-icon">👥</span>
                    <span>Data Anggota</span>
                </a>

                <a href="<?= base_url('index.php/buku'); ?>"
                   class="active">

                    <span class="menu-icon">📚</span>
                    <span>Data Buku</span>

                </a>

                <a href="#">
                    <span class="menu-icon">🏷️</span>
                    <span>Kategori</span>
                </a>

                <a href="#">
                    <span class="menu-icon">📖</span>
                    <span>Peminjaman</span>
                </a>

            </nav>

        </div>


        <div class="sidebar-logout">

            <a href="<?= base_url('index.php/login/logout'); ?>">

                <span>↪</span>
                <span>Keluar</span>

            </a>

        </div>

    </aside>


    <!-- MAIN -->

    <main class="main-content">

        <div class="topbar">

            <div class="topbar-title">

                <h1>Tambah Buku</h1>

                <p>
                    Tambahkan buku baru ke dalam sistem.
                </p>

            </div>


            <div class="admin-profile">

                <div class="admin-name">

                    <?= $this->session->userdata('nama_petugas'); ?>
                    - Administrator

                </div>

            </div>

        </div>


        <div class="content-card tambah-card">

            <div class="card-header">

                <div>

                    <h3>Form Data Buku</h3>

                    <span>
                        Lengkapi data buku dengan benar.
                    </span>

                </div>


                <div class="header-badge">
                    Buku Baru
                </div>

            </div>


            <div class="form-container">

                <form
                    action="<?= base_url('index.php/buku/tambah_aksi'); ?>"
                    method="POST"
                >

                    <div class="form-grid">


                        <!-- ID BUKU -->

                        <div class="form-group">

                            <label>ID Buku</label>

                            <div class="input-box">

                                <span>🆔</span>

                                <input
                                    type="text"
                                    name="id_buku"
                                    placeholder="Contoh: B026"
                                    required
                                >

                            </div>

                        </div>


                        <!-- JUDUL -->

                        <div class="form-group">

                            <label>Judul Buku</label>

                            <div class="input-box">

                                <span>📚</span>

                                <input
                                    type="text"
                                    name="judul"
                                    placeholder="Masukkan judul buku"
                                    required
                                >

                            </div>

                        </div>


                        <!-- PENGARANG -->

                        <div class="form-group">

                            <label>Pengarang</label>

                            <div class="input-box">

                                <span>✍️</span>

                                <input
                                    type="text"
                                    name="pengarang"
                                    placeholder="Masukkan nama pengarang"
                                    required
                                >

                            </div>

                        </div>


                        <!-- TAHUN -->

                        <div class="form-group">

                            <label>Tahun Terbit</label>

                            <div class="input-box">

                                <span>📅</span>

                                <input
                                    type="number"
                                    name="tahun"
                                    placeholder="Contoh: 2024"
                                    min="1900"
                                    max="2100"
                                    required
                                >

                            </div>

                        </div>


                        <!-- KATEGORI -->

                        <!-- KATEGORI -->

<!-- KATEGORI -->

<!-- =========================
     KATEGORI
========================= -->

<!-- =========================
     KATEGORI
========================= -->

<!-- =========================
     KATEGORI
========================= -->

<div class="form-group">

    <label>Kategori</label>

    <div class="input-box">

        <span>🏷️</span>

        <select
            name="id_kategori"
            required
            style="
                width:100%;
                border:none;
                outline:none;
                padding:15px 0;
                background:transparent;
                font-size:15px;
                font-family:Poppins,sans-serif;
                color:#252525;
                cursor:pointer;
            "
        >

            <option value="" disabled selected>
                Pilih kategori
            </option>

            <?php foreach ($kategori as $k): ?>

                <option value="<?= $k->id_kategori; ?>">

                    <?= $k->id_kategori; ?> - <?= $k->nama_kategori; ?>

                </option>

            <?php endforeach; ?>

        </select>

    </div>

</div>

                        <!-- STOK -->

<div class="form-group">

    <label>Stok Buku</label>

    <div class="input-box">

        <span>📦</span>

        <input
            type="number"
            name="stok"
            placeholder="Masukkan jumlah stok"
            min="0"
            required
        >

    </div>

</div>


                    <div class="form-actions">

                        <a
                            href="<?= base_url('index.php/buku'); ?>"
                            class="btn-cancel"
                        >

                            ← Batal

                        </a>


                        <button type="submit" class="btn-save">
    + Simpan Buku
</button>

                    </div>

                </form>

            </div>

        </div>

    </main>

</div>

</body>
</html>