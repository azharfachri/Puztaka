<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Edit Buku | Perpustakaan</title>

    <link rel="stylesheet"
          href="<?= base_url('aset/css/dashboard.css'); ?>">

    <link rel="stylesheet"
          href="<?= base_url('aset/css/anggota.css'); ?>">

    <link rel="stylesheet"
          href="<?= base_url('aset/css/tambah_anggota.css'); ?>">

</head>

<body>

<div class="dashboard-wrapper">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <div>

            <div class="sidebar-brand">

                <div class="sidebar-logo">

                    <img
                        src="<?= base_url('aset/img/logo_perpustakaan.png'); ?>"
                        alt="Logo Perpustakaan"
                    >

                </div>

                <h2>Perpustakaan</h2>

                <p>Sistem Informasi</p>

            </div>


            <nav class="sidebar-menu">

                <a href="<?= base_url('index.php/dashboard'); ?>">

                    <span class="menu-icon">⌂</span>
                    <span>Dashboard</span>

                </a>


                <a href="<?= base_url('index.php/anggota'); ?>">

                    <span class="menu-icon">👥</span>
                    <span>Data Anggota</span>

                </a>


                <a href="<?= base_url('index.php/buku'); ?>"
                   class="active">

                    <span class="menu-icon">📚</span>
                    <span>Data Buku</span>

                </a>


                <a href="<?= base_url('index.php/kategori'); ?>">

                    <span class="menu-icon">🏷️</span>
                    <span>Kategori</span>

                </a>


                <a href="<?= base_url('index.php/peminjaman'); ?>">

                    <span class="menu-icon">📖</span>
                    <span>Peminjaman</span>

                </a>

            </nav>

        </div>


        <div class="sidebar-logout">

            <a href="<?= base_url('index.php/login/logout'); ?>">

                <span>↪</span>
                <span>Keluar</span>

            </a>

        </div>

    </aside>


    <!-- MAIN -->

    <main class="main-content">

        <div class="topbar">

            <div class="topbar-title">

                <h1>Edit Buku</h1>

                <p>
                    Perbarui data buku perpustakaan.
                </p>

            </div>


            <div class="admin-profile">

                <div class="admin-name">

                    <?= $this->session->userdata('nama_petugas'); ?>
                    - Administrator

                </div>

            </div>

        </div>


        <div class="content-card tambah-card">

            <div class="card-header">

                <div>

                    <h3>Form Edit Buku</h3>

                    <span>
                        Ubah data buku sesuai kebutuhan.
                    </span>

                </div>


                <div class="header-badge">
                    Edit Data
                </div>

            </div>


            <div class="form-container">

                <form
                    action="<?= base_url('index.php/buku/edit_aksi'); ?>"
                    method="POST"
                >

                    <!-- ID LAMA -->
                    <input
                        type="hidden"
                        name="id_buku"
                        value="<?= $buku->id_buku; ?>"
                    >


                    <div class="form-grid">


                        <!-- ID BUKU -->

                        <div class="form-group">

                            <label>ID Buku</label>

                            <div class="input-box">

                                <span>🆔</span>

                                <input
                                    type="text"
                                    name="id_buku_baru"
                                    value="<?= $buku->id_buku; ?>"
                                    required
                                >

                            </div>

                        </div>


                        <!-- JUDUL BUKU -->

                        <div class="form-group">

                            <label>Judul Buku</label>

                            <div class="input-box">

                                <span>📚</span>

                                <input
                                    type="text"
                                    name="judul"
                                    value="<?= $buku->judul; ?>"
                                    required
                                >

                            </div>

                        </div>


                        <!-- PENGARANG -->

                        <div class="form-group">

                            <label>Pengarang</label>

                            <div class="input-box">

                                <span>✍️</span>

                                <input
                                    type="text"
                                    name="pengarang"
                                    value="<?= $buku->pengarang; ?>"
                                    required
                                >

                            </div>

                        </div>


                        <!-- TAHUN TERBIT -->

                        <div class="form-group">

                            <label>Tahun Terbit</label>

                            <div class="input-box">

                                <span>📅</span>

                                <input
                                    type="number"
                                    name="tahun"
                                    value="<?= $buku->tahun; ?>"
                                    min="1900"
                                    max="2100"
                                    required
                                >

                            </div>

                        </div>


                        <!-- KATEGORI -->

                        <div class="form-group">

                            <label>Kategori</label>

                            <div class="input-box">

                                <span>🏷️</span>

                                <select
                                    name="id_kategori"
                                    required
                                >

                                    <?php foreach ($kategori_list as $k): ?>

                                        <option
                                            value="<?= $k->id_kategori; ?>"
                                            <?= ($k->id_kategori == $buku->id_kategori) ? 'selected' : ''; ?>
                                        >

                                            <?= $k->id_kategori; ?>
                                            -
                                            <?= $k->nama_kategori; ?>

                                        </option>

                                    <?php endforeach; ?>

                                </select>

                            </div>

                        </div>


                        <!-- STOK BUKU -->

                        <div class="form-group">

                            <label>Stok Buku</label>

                            <div class="input-box">

                                <span>📦</span>

                                <input
                                    type="number"
                                    name="stok"
                                    value="<?= $buku->stok; ?>"
                                    min="0"
                                    required
                                >

                            </div>

                        </div>


                    </div>


                    <!-- BUTTON -->

                    <div class="form-actions">

                        <a
                            href="<?= base_url('index.php/buku'); ?>"
                            class="btn-cancel"
                        >

                            ← Batal

                        </a>


                        <button
                            type="submit"
                            class="btn-save"
                        >

                            ✓ Simpan Perubahan

                        </button>

                    </div>

                </form>

            </div>

        </div>

    </main>

</div>

</body>

</html>