<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        Login | Sistem Informasi Perpustakaan
    </title>

    <!-- CSS LOGIN -->
    <link
        rel="stylesheet"
        href="<?= base_url('assets/css/login.css'); ?>"
    >

</head>


<body>

<div class="login-page">

    <div class="login-container">


        <!-- =================================
             BAGIAN KIRI
        ================================== -->

        <div class="login-left">

            <div class="brand">

                <div class="brand-icon">
                    📚
                </div>


                <h1>
                    Sistem Informasi Perpustakaan
                </h1>


                <p>
                    Kelola kegiatan perpustakaan
                    dengan lebih mudah, cepat,
                    dan terorganisir.
                </p>

            </div>


            <div class="library-info">

                <div class="info-item">
                    📖 Koleksi Buku
                </div>

                <div class="info-item">
                    👥 Data Anggota
                </div>

                <div class="info-item">
                    🔄 Peminjaman
                </div>

            </div>

        </div>


        <!-- =================================
             BAGIAN KANAN
        ================================== -->

        <div class="login-right">

            <div class="login-form">


                <!-- HEADER LOGIN -->

                <div class="login-header">

                    <h2>
                        Hallo... 👋
                    </h2>

                    <p>
                        Silakan masuk untuk
                        melanjutkan.
                    </p>

                </div>


                <!-- =================================
                     PESAN ERROR
                ================================== -->

                <?php

                if (
                    $this->session
                        ->flashdata('error')
                ):

                ?>

                    <div class="alert">

                        <?=

                        $this->session
                            ->flashdata('error');

                        ?>

                    </div>

                <?php endif; ?>


                <!-- =================================
                     FORM LOGIN
                ================================== -->

                <form
                    action="<?= base_url('login/proses'); ?>"
                    method="POST"
                >


                    <!-- USERNAME -->

                    <div class="form-group">

                        <label for="username">
                            Username
                        </label>


                        <div class="input-wrapper">

                            <span
                                class="input-icon"
                            >
                                👤
                            </span>


                            <input
                                type="text"
                                id="username"
                                name="username"
                                class="form-control"
                                placeholder="Masukkan username"
                                autocomplete="username"
                                required
                            >

                        </div>

                    </div>


                    <!-- PASSWORD -->

                    <div class="form-group">

                        <label for="password">
                            Password
                        </label>


                        <div class="input-wrapper">

                            <span
                                class="input-icon"
                            >
                                🔒
                            </span>


                            <input
                                type="password"
                                id="password"
                                name="password"
                                class="form-control"
                                placeholder="Masukkan password"
                                autocomplete="current-password"
                                required
                            >


                            <button
                                type="button"
                                class="password-toggle"
                                id="togglePassword"
                            >
                                👁
                            </button>

                        </div>

                    </div>


                    <!-- =================================
                         BUTTON LOGIN
                    ================================== -->

                    <button
                        type="submit"
                        class="btn-login"
                    >
                        Masuk ke Sistem
                    </button>


                </form>


                <!-- =================================
                     FOOTER
                ================================== -->

                <div class="login-footer">

                    Sistem Informasi Perpustakaan

                    <br>

                    &copy;
                    <?= date('Y'); ?>

                </div>


            </div>

        </div>

    </div>

</div>


<!-- =================================
     JAVASCRIPT
================================== -->

<script
    src="<?= base_url('assets/js/login.js'); ?>"
></script>


</body>

</html>