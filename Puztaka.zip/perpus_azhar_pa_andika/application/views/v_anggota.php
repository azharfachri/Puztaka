<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Data Anggota | Perpustakaan</title>

    <link rel="stylesheet" href="<?= base_url('aset/css/anggota.css'); ?>">
</head>

<body>

<?php if ($this->session->flashdata('success')): ?>

<?php endif; ?>


<div class="dashboard-wrapper">

    <!-- ================= SIDEBAR ================= -->

    <aside class="sidebar">

        <div>

            <div class="sidebar-brand">

                <div class="sidebar-logo">

                    <img
                        src="<?= base_url('aset/img/logo_perpustakaan.png'); ?>"
                        alt="Logo Perpustakaan"
                    >

                </div>

                <h2>Perpustakaan</h2>

                <p>Sistem Informasi</p>

            </div>


            <nav class="sidebar-menu">

                <a href="<?= base_url('index.php/dashboard'); ?>">

                    <span class="menu-icon">⌂</span>

                    <span>Dashboard</span>

                </a>


                <a
                    href="<?= base_url('index.php/anggota'); ?>"
                    class="active"
                >

                    <span class="menu-icon">👥</span>

                    <span>Data Anggota</span>

                </a>


                <a href="<?= base_url('index.php/buku'); ?>">

                    <span class="menu-icon">📚</span>

                    <span>Data Buku</span>

                </a>


                <a href="<?= base_url('index.php/kategori'); ?>">

                    <span class="menu-icon">🏷️</span>

                    <span>Kategori</span>

                </a>


                <a href="<?= base_url('index.php/peminjaman'); ?>">

                    <span class="menu-icon">📖</span>

                    <span>Peminjaman</span>

                </a>

            </nav>

        </div>


        <!-- ================= LOGOUT ================= -->

        <div class="sidebar-logout">

            <a href="<?= base_url('index.php/login/logout'); ?>">

                ↪ Keluar

            </a>

        </div>

    </aside>


    <!-- ================= MAIN CONTENT ================= -->

    <main class="main-content">


        <!-- ================= TOPBAR ================= -->

        <div class="topbar">

            <div class="topbar-title">

                <h1>Data Anggota</h1>

                <p>
                    Kelola data anggota perpustakaan
                </p>

            </div>


            <div class="admin-profile">

                <div class="admin-name">

                    <?= $this->session->userdata('nama_petugas'); ?>

                    - Administrator

                </div>

            </div>

        </div>


        <!-- ================= CONTENT ================= -->

        <div class="content-card">


            <!-- ================= CARD HEADER ================= -->

            <div class="card-header">

                <div>

                    <h3>Daftar Anggota</h3>

                    <span>
                        Data seluruh anggota perpustakaan
                    </span>

                </div>


                <a
                    href="<?= base_url('index.php/anggota/tambah'); ?>"
                    class="btn-add"
                >

                    + Tambah Anggota

                </a>

            </div>


            <!-- ================= FILTER & PENCARIAN ================= -->

            <form
                class="filter-form"
                onsubmit="return false;"
            >

                <div class="filter-search">

                    <span>🔍</span>

                    <input
                        type="text"
                        id="searchNama"
                        placeholder="Cari ID anggota, nama, atau kelas..."
                        autocomplete="off"
                    >

                </div>


                <select id="filterKelas">

                    <option value="">
                        Semua Kelas
                    </option>

                    <?php foreach($kelas_list as $k): ?>

                        <option
                            value="<?= strtolower($k->kelas); ?>"
                        >

                            <?= $k->kelas; ?>

                        </option>

                    <?php endforeach; ?>

                </select>


                <button
                    type="button"
                    class="btn-filter"
                    id="btnFilter"
                >

                    Cari

                </button>


                <button
                    type="button"
                    class="btn-reset"
                    id="resetFilter"
                >

                    Reset

                </button>

            </form>


            <!-- ================= TABEL ================= -->

            <div class="table-wrapper">

                <table id="tabelAnggota">

                    <thead>

                        <tr>

                            <th>No</th>

                            <th>ID Anggota</th>

                            <th>Nama</th>

                            <th>Kelas</th>

                            <th>Alamat</th>

                            <th>Aksi</th>

                        </tr>

                    </thead>


                    <tbody>

                        <?php $no = 1; ?>


                        <?php foreach ($anggota as $data): ?>

                            <tr
                                data-id="<?= strtolower($data->id_anggota); ?>"
                                data-nama="<?= strtolower($data->nama); ?>"
                                data-kelas="<?= strtolower($data->kelas); ?>"
                            >

                                <td>

                                    <?= $no++; ?>

                                </td>


                                <td>

                                    <?= $data->id_anggota; ?>

                                </td>


                                <td>

                                    <?= $data->nama; ?>

                                </td>


                                <td>

                                    <?= $data->kelas; ?>

                                </td>


                                <td>

                                    <?= $data->alamat; ?>

                                </td>


                                <td class="action-buttons">

                                    <a
                                        href="<?= base_url('index.php/anggota/edit/'.$data->id_anggota); ?>"
                                        class="btn-action btn-edit"
                                    >

                                        Edit

                                    </a>


                                    <a
                                        href="<?= base_url('index.php/anggota/hapus/'.$data->id_anggota); ?>"
                                        class="btn-action btn-delete"
                                        onclick="return confirm('Yakin ingin menghapus anggota ini?');"
                                    >

                                        Hapus

                                    </a>

                                </td>

                            </tr>

                        <?php endforeach; ?>


                    </tbody>

                </table>

            </div>

        </div>

    </main>

</div>


<!-- ================= SWEETALERT ================= -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<?php if ($this->session->flashdata('success')): ?>

<script>

Swal.fire({

    toast: true,

    position: 'top-end',

    icon: 'success',

    title: '<?= $this->session->flashdata('success'); ?>',

    showConfirmButton: false,

    timer: 3000,

    timerProgressBar: true

});

</script>

<?php endif; ?>


<?php if ($this->session->flashdata('error')): ?>

<script>

Swal.fire({

    toast: true,

    position: 'top-end',

    icon: 'error',

    title: '<?= $this->session->flashdata('error'); ?>',

    showConfirmButton: false,

    timer: 3000,

    timerProgressBar: true

});

</script>

<?php endif; ?>


<!-- ================= JAVASCRIPT ANGGOTA ================= -->

<script src="<?= base_url('aset/js/anggota.js'); ?>"></script>


</body>
</html>