<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Data Kategori | Perpustakaan</title>

    <link
    rel="stylesheet"
    href="<?= base_url('aset/css/dashboard.css'); ?>"
>

<link
    rel="stylesheet"
    href="<?= base_url('aset/css/anggota.css'); ?>"
>

<link
    rel="stylesheet"
    href="<?= base_url('aset/css/tambah_anggota.css'); ?>"
>

<link
    rel="stylesheet"
    href="<?= base_url('aset/css/kategori.css'); ?>"
>

</head>


<body>

<div class="dashboard-wrapper">


    <!-- =====================================================
         SIDEBAR
    ====================================================== -->

    <aside class="sidebar">

        <div>

            <div class="sidebar-brand">

                <div class="sidebar-logo">

                    <img
                        src="<?= base_url('aset/img/logo_perpustakaan.png'); ?>"
                        alt="Logo Perpustakaan"
                    >

                </div>

                <h2>Perpustakaan</h2>

                <p>Sistem Informasi</p>

            </div>


            <nav class="sidebar-menu">

    <a href="<?= base_url('index.php/dashboard'); ?>">
        <span class="menu-icon">⌂</span>
        <span>Dashboard</span>
    </a>

    <a href="<?= base_url('index.php/anggota'); ?>">
        <span class="menu-icon">👥</span>
        <span>Data Anggota</span>
    </a>

    <a href="<?= base_url('index.php/buku'); ?>">
        <span class="menu-icon">📚</span>
        <span>Data Buku</span>
    </a>

    <a href="<?= base_url('index.php/kategori'); ?>" class="active">
        <span class="menu-icon">🏷️</span>
        <span>Kategori</span>
    </a>

    <a href="<?= base_url('index.php/peminjaman'); ?>">
        <span class="menu-icon">📖</span>
        <span>Peminjaman</span>
    </a>

</nav>
        </div>


        <!-- LOGOUT -->

        <div class="sidebar-logout">

            <a href="<?= base_url('index.php/login/logout'); ?>">

                <span>↪</span>
                <span>Keluar</span>

            </a>

        </div>

    </aside>



    <!-- =====================================================
         MAIN CONTENT
    ====================================================== -->

    <main class="main-content">


        <!-- TOPBAR -->

        <div class="topbar">

            <div class="topbar-title">

                <h1>Data Kategori</h1>

                <p>
                    Kelola kategori buku perpustakaan.
                </p>

            </div>


            <div class="admin-profile">

                <div class="admin-name">

                    <?= $this->session->userdata('nama_petugas'); ?>

                    - Administrator

                </div>

            </div>

        </div>



    


        <!-- =================================================
             CARD DATA KATEGORI
        ================================================== -->

        <div class="content-card kategori-card">


            <!-- HEADER CARD -->

            <div class="kategori-header">

                <div>

                    <h3>Daftar Kategori</h3>

                    <span>
                        Daftar kategori buku yang tersedia.
                    </span>

                </div>


                <!-- TAMBAH KATEGORI -->

                <a
                    href="<?= base_url('index.php/kategori/tambah'); ?>"
                    class="btn-tambah"
                >

                    + Tambah Kategori

                </a>

            </div>



            <!-- =================================================
                 PENCARIAN
            ================================================== -->

            <form
                action="<?= base_url('index.php/kategori'); ?>"
                method="GET"
                class="search-form"
                onsubmit="return false;"
            >

                <div class="search-box">

                    <span class="search-icon">
                        🔎
                    </span>


                    <input
                        type="text"
                        id="keywordKategori"
                        name="keyword"
                        value="<?= html_escape($this->input->get('keyword')); ?>"
                        placeholder="Cari ID atau nama kategori..."
                        autocomplete="off"
                    >


                    <button
                        type="button"
                        id="clearSearch"
                        class="search-clear"
                        title="Hapus pencarian"
                        style="display:none;"
                    >

                        ×

                    </button>

                </div>


                <button
                    type="button"
                    class="btn-search"
                    id="btnCari"
                >

                    Cari

                </button>

            </form>



            <!-- =================================================
                 TABEL KATEGORI
            ================================================== -->

            <div class="table-wrapper">

                <table class="kategori-table">

                    <thead>

                        <tr>

                            <th width="10%">
                                No
                            </th>

                            <th width="25%">
                                ID Kategori
                            </th>

                            <th>
                                Nama Kategori
                            </th>

                            <th width="20%">
                                Aksi
                            </th>

                        </tr>

                    </thead>


                    <tbody id="kategoriTableBody">


                        <?php if (!empty($kategori)): ?>

                            <?php $no = 1; ?>


                            <?php foreach ($kategori as $k): ?>

                                <tr
                                    class="kategori-row"
                                    data-id="<?= strtolower(html_escape($k->id_kategori)); ?>"
                                    data-nama="<?= strtolower(html_escape($k->nama_kategori)); ?>"
                                >


                                    <!-- NOMOR -->

                                    <td data-label="No">

                                        <?= $no++; ?>

                                    </td>


                                    <!-- ID KATEGORI -->

                                    <td data-label="ID Kategori">

                                        <span class="kode-kategori">

                                            <?= html_escape($k->id_kategori); ?>

                                        </span>

                                    </td>


                                    <!-- NAMA KATEGORI -->

                                    <td data-label="Nama Kategori">

                                        <span class="nama-kategori">

                                            <?= html_escape($k->nama_kategori); ?>

                                        </span>

                                    </td>


                                    <!-- AKSI -->

                                    <td
                                        data-label="Aksi"
                                        class="aksi-cell"
                                    >


                                        <!-- EDIT -->

                                        <a
                                            href="<?= base_url('index.php/kategori/edit/' . $k->id_kategori); ?>"
                                            class="btn-edit"
                                            title="Edit Kategori"
                                        >

                                            Edit

                                        </a>


                                        <!-- HAPUS -->

                                        <a href="<?= base_url('index.php/kategori/hapus/'.$k->id_kategori); ?>" class="btn-hapus">
    Hapus
</a>
                                    </td>

                                </tr>

                            <?php endforeach; ?>


                            <!-- DATA TIDAK DITEMUKAN SAAT LIVE SEARCH -->

                            <tr
                                id="searchEmpty"
                                style="display:none;"
                            >

                                <td
                                    colspan="4"
                                    class="data-kosong"
                                >

                                    <div class="empty-icon">
                                        🏷️
                                    </div>

                                    <strong>
                                        Data kategori tidak ditemukan
                                    </strong>

                                    <span>
                                        Tidak ada kategori yang sesuai dengan pencarian.
                                    </span>

                                </td>

                            </tr>


                        <?php else: ?>


                            <!-- DATA KOSONG DARI DATABASE -->

                            <tr>

                                <td
                                    colspan="4"
                                    class="data-kosong"
                                >

                                    <div class="empty-icon">
                                        🏷️
                                    </div>

                                    <strong>
                                        Data kategori tidak ditemukan
                                    </strong>

                                    <span>
                                        Belum ada kategori yang tersedia.
                                    </span>

                                </td>

                            </tr>


                        <?php endif; ?>


                    </tbody>

                </table>

            </div>


        </div>

    </main>

</div>



<!-- =====================================================
     LIVE SEARCH KATEGORI
===================================================== -->

<script>

document.addEventListener('DOMContentLoaded', function () {

    const searchInput =
        document.getElementById('keywordKategori');

    const clearButton =
        document.getElementById('clearSearch');

    const searchButton =
        document.getElementById('btnCari');

    const rows =
        document.querySelectorAll('.kategori-row');

    const emptyRow =
        document.getElementById('searchEmpty');


    function liveSearch() {

        const keyword =
            searchInput.value
                .trim()
                .toLowerCase();


        let ditemukan = 0;


        rows.forEach(function (row) {

            const id =
                row.getAttribute('data-id') || '';

            const nama =
                row.getAttribute('data-nama') || '';


            /*
             * CARI ID ATAU NAMA KATEGORI
             */

            if (
                id.includes(keyword) ||
                nama.includes(keyword)
            ) {

                row.style.display = '';

                ditemukan++;

            } else {

                row.style.display = 'none';

            }

        });


        /*
         * TAMPILKAN PESAN JIKA TIDAK ADA HASIL
         */

        if (emptyRow) {

            if (
                keyword !== '' &&
                ditemukan === 0
            ) {

                emptyRow.style.display = '';

            } else {

                emptyRow.style.display = 'none';

            }

        }


        /*
         * TOMBOL X
         */

        if (keyword !== '') {

            clearButton.style.display = 'flex';

        } else {

            clearButton.style.display = 'none';

        }

    }


    /*
     * LIVE SEARCH
     *
     * Setiap kali mengetik,
     * langsung melakukan pencarian.
     */

    searchInput.addEventListener(
        'input',
        liveSearch
    );


    /*
     * TOMBOL CARI
     */

    searchButton.addEventListener(
        'click',
        liveSearch
    );


    /*
     * TOMBOL X
     */

    clearButton.addEventListener(
        'click',
        function () {

            searchInput.value = '';

            liveSearch();

            searchInput.focus();

        }
    );


    /*
     * JIKA HALAMAN DIBUKA
     * DENGAN KEYWORD
     */

    liveSearch();

});



/* =====================================================
   NOTIFIKASI OTOMATIS HILANG
===================================================== */

setTimeout(function () {

    const alerts =
        document.querySelectorAll('.alert');


    alerts.forEach(function (alert) {

        alert.style.opacity = '0';

        alert.style.transform =
            'translateY(-10px)';


        setTimeout(function () {

            alert.remove();

        }, 300);

    });

}, 3000);

</script>

<script src="<?= base_url('aset/js/kategori.js'); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<?php if ($this->session->flashdata('success')): ?>
<script>
Swal.fire({
    toast:true,
    position:'top-end',
    icon:'success',
    title:'<?= $this->session->flashdata('success'); ?>',
    showConfirmButton:false,
    timer:3000,
    timerProgressBar:true
});
</script>
<?php endif; ?>

<?php if ($this->session->flashdata('error')): ?>
<script>
Swal.fire({
    toast:true,
    position:'top-end',
    icon:'error',
    title:'<?= $this->session->flashdata('error'); ?>',
    showConfirmButton:false,
    timer:3500,
    timerProgressBar:true
});
</script>
<?php endif; ?>

</body>
</html>