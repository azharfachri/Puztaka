<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Edit Anggota | Perpustakaan</title>

    <link rel="stylesheet"
          href="<?= base_url('aset/css/dashboard.css'); ?>">

    <link rel="stylesheet"
          href="<?= base_url('aset/css/anggota.css'); ?>">

    <link rel="stylesheet"
          href="<?= base_url('aset/css/tambah_anggota.css'); ?>">

</head>


<body>


<div class="dashboard-wrapper">


    <!-- =========================
         SIDEBAR
    ========================== -->

    <aside class="sidebar">

        <div>

            <div class="sidebar-brand">

                <div class="sidebar-logo">

                    <img
                        src="<?= base_url('aset/img/logo_perpustakaan.png'); ?>"
                        alt="Logo Perpustakaan"
                    >

                </div>


                <h2>Perpustakaan</h2>

                <p>Sistem Informasi</p>

            </div>


            <nav class="sidebar-menu">


                <a href="<?= base_url('index.php/dashboard'); ?>">

                    <span class="menu-icon">⌂</span>

                    <span>Dashboard</span>

                </a>


                <a
                    href="<?= base_url('index.php/anggota'); ?>"
                    class="active"
                >

                    <span class="menu-icon">👥</span>

                    <span>Data Anggota</span>

                </a>


                <a href="<?= base_url('index.php/buku'); ?>">

                    <span class="menu-icon">📚</span>

                    <span>Data Buku</span>

                </a>


                <a href="<?= base_url('index.php/kategori'); ?>">

                    <span class="menu-icon">🏷️</span>

                    <span>Kategori</span>

                </a>


                <a href="<?= base_url('index.php/peminjaman'); ?>">

                    <span class="menu-icon">📖</span>

                    <span>Peminjaman</span>

                </a>


            </nav>

        </div>


        <!-- =========================
             LOGOUT
        ========================== -->

        <div class="sidebar-logout">

            <a href="<?= base_url('index.php/login/logout'); ?>">

                ↪ Keluar

            </a>

        </div>


    </aside>


    <!-- =========================
         MAIN CONTENT
    ========================== -->

    <main class="main-content">


        <!-- =========================
             TOPBAR
        ========================== -->

        <div class="topbar">


            <div class="topbar-title">

                <h1>Edit Anggota</h1>

                <p>
                    Perbarui data anggota perpustakaan.
                </p>

            </div>


            <div class="admin-profile">

                <div class="admin-name">

                    <?= $this->session->userdata('nama_petugas'); ?>

                    - Administrator

                </div>

            </div>


        </div>


        <!-- =========================
             CONTENT CARD
        ========================== -->

        <div class="content-card tambah-card">


            <!-- =========================
                 HEADER
            ========================== -->

            <div class="card-header">


                <div>

                    <h3>Form Edit Anggota</h3>

                    <span>
                        Ubah data anggota sesuai kebutuhan.
                    </span>

                </div>


                <div class="header-badge">

                    Edit Data

                </div>


            </div>


            <!-- =========================
                 FORM
            ========================== -->

            <div class="form-container">


                <form
                    action="<?= base_url('index.php/anggota/edit_aksi'); ?>"
                    method="POST"
                >


                    <!--
                        ID LAMA

                        Ini disimpan secara hidden supaya
                        controller tahu ID anggota sebelum
                        diedit.
                    -->

                    <input
                        type="hidden"
                        name="id_anggota"
                        value="<?= $anggota->id_anggota; ?>"
                    >


                    <div class="form-grid">


                        <!-- =========================
                             ID ANGGOTA BARU
                        ========================== -->

                        <div class="form-group">


                            <label>ID Anggota</label>


                            <div class="input-box">


                                <span>🆔</span>


                                <input
                                    type="text"
                                    name="id_anggota_baru"
                                    value="<?= $anggota->id_anggota; ?>"
                                    required
                                >


                            </div>


                        </div>


                        <!-- =========================
                             NAMA
                        ========================== -->

                        <div class="form-group">


                            <label>Nama</label>


                            <div class="input-box">


                                <span>👤</span>


                                <input
                                    type="text"
                                    name="nama"
                                    value="<?= $anggota->nama; ?>"
                                    required
                                >


                            </div>


                        </div>


                        <!-- =========================
                             KELAS
                        ========================== -->

                        <div class="form-group">


                            <label>Kelas</label>


                            <div class="input-box">


                                <span>🏫</span>


                                <input
                                    type="text"
                                    name="kelas"
                                    value="<?= $anggota->kelas; ?>"
                                    required
                                >


                            </div>


                        </div>


                        <!-- =========================
                             ALAMAT
                        ========================== -->

                        <div class="form-group full">


                            <label>Alamat</label>


                            <div class="input-box">


                                <span>📍</span>


                                <input
                                    type="text"
                                    name="alamat"
                                    value="<?= $anggota->alamat; ?>"
                                    required
                                >


                            </div>


                        </div>


                    </div>


                    <!-- =========================
                         BUTTON
                    ========================== -->

                    <div class="form-actions">


                        <a
                            href="<?= base_url('index.php/anggota'); ?>"
                            class="btn-cancel"
                        >

                            ← Batal

                        </a>


                        <button
                            type="submit"
                            class="btn-save"
                        >

                            ✓ Simpan Perubahan

                        </button>


                    </div>


                </form>


            </div>


        </div>


    </main>


</div>


</body>

</html>