<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Edit Peminjaman</title>

<link rel="stylesheet" href="<?= base_url('aset/css/dashboard.css');?>">
<link rel="stylesheet" href="<?= base_url('aset/css/anggota.css');?>">
<link rel="stylesheet" href="<?= base_url('aset/css/tambah_anggota.css');?>">
<link rel="stylesheet" href="<?= base_url('aset/css/peminjaman.css');?>">

</head>

<body>

<div class="dashboard-wrapper">

<aside class="sidebar">

<div>

<div class="sidebar-brand">

<div class="sidebar-logo">

<img src="<?= base_url('aset/img/logo_perpustakaan.png');?>">

</div>

<h2>Perpustakaan</h2>
<p>Sistem Informasi</p>

</div>

<nav class="sidebar-menu">

<a href="<?= base_url('index.php/dashboard');?>"><span class="menu-icon">⌂</span><span>Dashboard</span></a>
<a href="<?= base_url('index.php/anggota');?>"><span class="menu-icon">👥</span><span>Data Anggota</span></a>
<a href="<?= base_url('index.php/buku');?>"><span class="menu-icon">📚</span><span>Data Buku</span></a>
<a href="<?= base_url('index.php/kategori');?>"><span class="menu-icon">🏷️</span><span>Kategori</span></a>
<a href="<?= base_url('index.php/peminjaman');?>" class="active"><span class="menu-icon">📖</span><span>Peminjaman</span></a>

</nav>

</div>

<div class="sidebar-logout">

<a href="<?= base_url('index.php/login/logout');?>">

↪ Keluar

</a>

</div>

</aside>

<main class="main-content">

<div class="topbar">

<div class="topbar-title">

<h1>Edit Peminjaman</h1>
<p>Perbarui data peminjaman.</p>

</div>

<div class="admin-profile">

<div class="admin-name">

<?= $this->session->userdata('nama_petugas');?> - Administrator

</div>

</div>

</div>

<div class="content-card tambah-card">

<div class="card-header">

<div>

<h3>Form Edit Peminjaman</h3>
<span>Ubah data sesuai kebutuhan.</span>

</div>

<div class="header-badge">

Edit Data

</div>

</div>

<div class="form-container">

<form action="<?= base_url('index.php/peminjaman/edit_aksi');?>" method="POST">

<input type="hidden"
name="id_pinjam"
value="<?= $peminjaman->id_pinjam;?>">

<div class="form-grid">

<div class="form-group">

<label>Anggota</label>

<div class="input-box">

<span>👤</span>

<select name="id_anggota">

<?php foreach($anggota as $a):?>

<option
value="<?= $a->id_anggota;?>"
<?= $a->id_anggota==$peminjaman->id_anggota?'selected':'';?>>

<?= $a->id_anggota;?> - <?= $a->nama;?>

</option>

<?php endforeach;?>

</select>

</div>

</div>

<div class="form-group">

<label>Buku</label>

<div class="input-box">

<span>📚</span>

<select name="id_buku">

<?php foreach($buku as $b):?>

<option
value="<?= $b->id_buku;?>"
<?= $b->id_buku==$peminjaman->id_buku?'selected':'';?>>

<?= $b->id_buku;?> - <?= $b->judul;?>

</option>

<?php endforeach;?>

</select>

</div>

</div>

<div class="form-group">

<label>Tanggal Pinjam</label>

<div class="input-box">

<span>📅</span>

<input
id="tanggal_pinjam"
type="date"
name="tanggal_pinjam"
value="<?= $peminjaman->tanggal_pinjam;?>">

</div>

</div>

<div class="form-group">

<label>Estimasi Kembali</label>

<div class="input-box">

<span>⏳</span>

<input
id="tanggal_jatuh_tempo"
type="date"
value="<?= $peminjaman->tanggal_jatuh_tempo;?>"
readonly>

</div>

</div>

<div class="form-group">

<label>Tanggal Kembali</label>

<div class="input-box">

<span>📆</span>

<input
id="tanggal_kembali"
type="date"
name="tanggal_kembali"
value="<?= $peminjaman->tanggal_kembali;?>">

</div>

</div>

<div class="form-group">

<label>Keterangan</label>

<div class="input-box">

<span>🔄</span>

<select
name="keterangan"
id="statusSelect">

<option value="Dipinjam"
<?= $peminjaman->keterangan=="Dipinjam"?'selected':'';?>>

Dipinjam

</option>

<option value="Tepat Waktu"
<?= $peminjaman->keterangan=="Tepat Waktu"?'selected':'';?>>

Tepat Waktu

</option>

<option value="Terlambat"
<?= $peminjaman->keterangan=="Terlambat"?'selected':'';?>>

Terlambat

</option>

</select>

</div>

<caption>Status otomatis berubah, tapi tetap bisa diubah manual.</caption>

</div>

</div>

<div class="form-actions">

<a href="<?= base_url('index.php/peminjaman');?>"
class="btn-cancel">

← Batal

</a>

<button type="submit"
class="btn-save">

✓ Simpan Perubahan

</button>

</div>

</form>

</div>

</div>

</main>

</div>

<script>

const pinjam=document.getElementById("tanggal_pinjam");

const kembali=document.getElementById("tanggal_kembali");

const tempo=document.getElementById("tanggal_jatuh_tempo");

const status=document.getElementById("statusSelect");

let manual=false;

status.addEventListener("change",()=>{

manual=true;

});

function updateData(){

let t=new Date(pinjam.value);

t.setDate(t.getDate()+5);

tempo.value=t.toISOString().split("T")[0];

if(!manual&&kembali.value){

let batas=new Date(tempo.value);

let balik=new Date(kembali.value);

status.value=balik>batas?"Terlambat":"Tepat Waktu";

}

}

pinjam.addEventListener("change",updateData);

kembali.addEventListener("change",updateData);

updateData();

</script>

</body>
</html>