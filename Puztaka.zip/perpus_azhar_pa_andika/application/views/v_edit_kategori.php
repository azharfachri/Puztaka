<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport"
          content="width=device-width, initial-scale=1.0">

    <title>Edit Kategori | Perpustakaan</title>

    <link rel="stylesheet"
          href="<?= base_url('aset/css/dashboard.css'); ?>">

    <link rel="stylesheet"
          href="<?= base_url('aset/css/anggota.css'); ?>">

    <link rel="stylesheet"
          href="<?= base_url('aset/css/tambah_anggota.css'); ?>">

</head>

<body>

<div class="dashboard-wrapper">

    <!-- SIDEBAR -->

    <aside class="sidebar">

        <div>

            <div class="sidebar-brand">

                <div class="sidebar-logo">

                    <img
                        src="<?= base_url('aset/img/logo_perpustakaan.png'); ?>"
                        alt="Logo Perpustakaan">

                </div>

                <h2>Perpustakaan</h2>

                <p>Sistem Informasi</p>

            </div>


            <nav class="sidebar-menu">

                <a href="<?= base_url('index.php/dashboard'); ?>">
                    <span class="menu-icon">⌂</span>
                    <span>Dashboard</span>
                </a>

                <a href="<?= base_url('index.php/anggota'); ?>">
                    <span class="menu-icon">👥</span>
                    <span>Data Anggota</span>
                </a>

                <a href="<?= base_url('index.php/buku'); ?>">
                    <span class="menu-icon">📚</span>
                    <span>Data Buku</span>
                </a>

                <a href="<?= base_url('index.php/kategori'); ?>" class="active">
                    <span class="menu-icon">🏷️</span>
                    <span>Kategori</span>
                </a>

                <a href="<?= base_url('index.php/peminjaman'); ?>">
                    <span class="menu-icon">📖</span>
                    <span>Peminjaman</span>
                </a>

            </nav>

        </div>


        <!-- LOGOUT -->

        <div class="sidebar-logout">

            <a href="<?= base_url('index.php/login/logout'); ?>">

                <span>↪</span>
                <span>Keluar</span>

            </a>

        </div>

    </aside>


    <!-- MAIN -->

    <main class="main-content">


        <!-- TOPBAR -->

        <div class="topbar">

            <div class="topbar-title">

                <h1>Edit Kategori</h1>

                <p>
                    Perbarui data kategori buku.
                </p>

            </div>


            <div class="admin-profile">

                <div class="admin-name">

                    <?= $this->session->userdata('nama_petugas'); ?>

                    - Administrator

                </div>

            </div>

        </div>


        <!-- CONTENT -->

        <div class="content-card tambah-card">

            <div class="card-header">

                <div>

                    <h3>Form Edit Kategori</h3>

                    <span>
                        Ubah data kategori sesuai kebutuhan.
                    </span>

                </div>


                <div class="header-badge">
                    Edit Data
                </div>

            </div>


            <div class="form-container">

                <form
                    action="<?= base_url('index.php/kategori/edit_aksi'); ?>"
                    method="POST"
                >

                    <div class="form-grid">


                        <!-- =========================
                             ID KATEGORI LAMA
                        ========================== -->

                        <input
                            type="hidden"
                            name="id_kategori"
                            value="<?= $kategori->id_kategori; ?>"
                        >


                        <!-- =========================
                             ID KATEGORI BARU
                        ========================== -->

                        <div class="form-group">

                            <label>ID Kategori</label>

                            <div class="input-box">

                                <span>🏷️</span>

                                <input
                                    type="text"
                                    name="id_kategori_baru"
                                    value="<?= $kategori->id_kategori; ?>"
                                    required
                                >

                            </div>

                        </div>


                        <!-- =========================
                             NAMA KATEGORI
                        ========================== -->

                        <div class="form-group">

                            <label>Nama Kategori</label>

                            <div class="input-box">

                                <span>📚</span>

                                <input
                                    type="text"
                                    name="nama_kategori"
                                    value="<?= $kategori->nama_kategori; ?>"
                                    required
                                >

                            </div>

                        </div>


                    </div>


                    <!-- =========================
                         BUTTON
                    ========================== -->

                    <div class="form-actions">

                        <a
                            href="<?= base_url('index.php/kategori'); ?>"
                            class="btn-cancel"
                        >

                            ← Batal

                        </a>


                        <button
                            type="submit"
                            class="btn-save"
                        >

                            ✓ Simpan Perubahan

                        </button>

                    </div>

                </form>

            </div>

        </div>

    </main>

</div>


<!-- SWEETALERT -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<?php if ($this->session->flashdata('success')): ?>

<script>

Swal.fire({

    toast: true,

    position: 'top-end',

    icon: 'success',

    title: '<?= $this->session->flashdata('success'); ?>',

    showConfirmButton: false,

    timer: 3000,

    timerProgressBar: true

});

</script>

<?php endif; ?>


<?php if ($this->session->flashdata('error')): ?>

<script>

Swal.fire({

    toast: true,

    position: 'top-end',

    icon: 'error',

    title: '<?= $this->session->flashdata('error'); ?>',

    showConfirmButton: false,

    timer: 3000,

    timerProgressBar: true

});

</script>

<?php endif; ?>


</body>
</html>