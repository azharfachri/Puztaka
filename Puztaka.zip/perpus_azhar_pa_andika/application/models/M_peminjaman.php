<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_peminjaman extends CI_Model
{
    public function get_all()
    {
        return $this->db
            ->select('peminjaman.*, anggota.nama, buku.judul')
            ->from('peminjaman')
            ->join('anggota','anggota.id_anggota=peminjaman.id_anggota')
            ->join('buku','buku.id_buku=peminjaman.id_buku')
            ->order_by('id_pinjam','DESC')
            ->get()
            ->result();
    }

    public function get_by_id($id)
    {
        return $this->db
            ->where('id_pinjam',$id)
            ->get('peminjaman')
            ->row();
    }

    public function tambah($data)
    {
        return $this->db->insert('peminjaman',$data);
    }

    public function edit($id,$data)
    {
        return $this->db
            ->where('id_pinjam',$id)
            ->update('peminjaman',$data);
    }

    public function hapus($id)
    {
        return $this->db
            ->where('id_pinjam',$id)
            ->delete('peminjaman');
    }

    // =========================
    // KURANGI STOK BUKU
    // =========================
    public function kurangi_stok($id_buku)
    {
        $this->db->set('stok','stok-1',FALSE);
        $this->db->where('id_buku',$id_buku);
        return $this->db->update('buku');
    }

    // =========================
    // TAMBAH STOK BUKU
    // =========================
    public function tambah_stok($id_buku)
    {
        $this->db->set('stok','stok+1',FALSE);
        $this->db->where('id_buku',$id_buku);
        return $this->db->update('buku');
    }
}