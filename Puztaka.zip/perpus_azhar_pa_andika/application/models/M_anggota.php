<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_anggota extends CI_Model
{
    // Mengambil semua data anggota
    public function get_all()
    {
        return $this->db
            ->order_by('id_anggota', 'ASC')
            ->get('anggota')
            ->result();
    }

    // Menambahkan anggota
    public function insert($data)
    {
        return $this->db
            ->insert('anggota', $data);
    }

    // Menghapus anggota
    public function delete($id)
    {
        return $this->db
            ->where('id_anggota', $id)
            ->delete('anggota');
    }
}