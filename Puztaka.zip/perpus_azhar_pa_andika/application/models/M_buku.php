<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_buku extends CI_Model
{
    // Mengambil semua buku
    public function get_all()
    {
        return $this->db
            ->order_by('id_buku', 'ASC')
            ->get('buku')
            ->result();
    }

    // Menambahkan buku
    public function insert($data)
    {
        return $this->db
            ->insert('buku', $data);
    }

    // Menghapus buku
    public function delete($id)
    {
        return $this->db
            ->where('id_buku', $id)
            ->delete('buku');
    }
}