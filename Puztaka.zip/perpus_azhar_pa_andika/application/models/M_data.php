<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_data extends CI_Model
{
    public function cek_login($where)
    {
        return $this->db
            ->where($where)
            ->get('petugas');
    }
}