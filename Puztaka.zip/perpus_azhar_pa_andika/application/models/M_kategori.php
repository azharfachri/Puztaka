<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_kategori extends CI_Model
{
    // =========================
    // AMBIL SEMUA KATEGORI
    // =========================
    public function get_all()
    {
        return $this->db
            ->order_by('id_kategori', 'ASC')
            ->get('kategori')
            ->result();
    }


    // =========================
    // AMBIL 1 KATEGORI
    // =========================
    public function get_by_id($id)
    {
        return $this->db
            ->where('id_kategori', $id)
            ->get('kategori')
            ->row();
    }


    // =========================
    // TAMBAH KATEGORI
    // =========================
    public function tambah($data)
    {
        return $this->db->insert('kategori', $data);
    }


    // =========================
    // EDIT KATEGORI
    // =========================
    public function edit($id, $data)
    {
        return $this->db
            ->where('id_kategori', $id)
            ->update('kategori', $data);
    }


    // =========================
    // HAPUS KATEGORI
    // =========================
    public function hapus($id)
    {
        return $this->db
            ->where('id_kategori', $id)
            ->delete('kategori');
    }
}