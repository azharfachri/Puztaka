<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class M_dashboard extends CI_Model
{
    public function jumlah_anggota()
    {
        return $this->db->count_all('anggota');
    }

    public function jumlah_buku()
    {
        return $this->db->count_all('buku');
    }

    public function jumlah_kategori()
    {
        return $this->db->count_all('kategori');
    }

    public function jumlah_peminjaman()
    {
        return $this->db->count_all('peminjaman');
    }
}