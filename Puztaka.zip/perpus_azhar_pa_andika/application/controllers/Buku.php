<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buku extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->database();
        $this->load->library('session');
    }


    // =========================
    // HALAMAN DATA BUKU
    // =========================
    public function index()
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }

        $keyword  = $this->input->get('keyword');
        $kategori = $this->input->get('kategori');

        $this->db
            ->select('buku.*, kategori.nama_kategori')
            ->from('buku')
            ->join(
                'kategori',
                'kategori.id_kategori = buku.id_kategori',
                'left'
            );


        // =========================
        // PENCARIAN
        // =========================
        // Bisa mencari berdasarkan:
        // - ID Buku
        // - Judul Buku
        // - Pengarang
        // - ID Kategori
        // - Nama Kategori
        // =========================

        if (!empty($keyword)) {

            $this->db->group_start();

            $this->db->like(
                'buku.id_buku',
                $keyword
            );

            $this->db->or_like(
                'buku.judul',
                $keyword
            );

            $this->db->or_like(
                'buku.pengarang',
                $keyword
            );

            $this->db->or_like(
                'buku.id_kategori',
                $keyword
            );

            $this->db->or_like(
                'kategori.nama_kategori',
                $keyword
            );

            $this->db->group_end();
        }


        // =========================
        // FILTER KATEGORI
        // =========================

        if (!empty($kategori)) {

            $this->db->where(
                'buku.id_kategori',
                $kategori
            );
        }


        // =========================
        // URUTKAN DATA
        // =========================

        $this->db->order_by(
            'buku.id_buku',
            'ASC'
        );


        // =========================
        // AMBIL DATA BUKU
        // =========================

        $data['buku'] = $this->db
            ->get()
            ->result();


        // =========================
        // DAFTAR KATEGORI
        // =========================

        $data['kategori_list'] = $this->db
            ->order_by(
                'id_kategori',
                'ASC'
            )
            ->get('kategori')
            ->result();


        // =========================
        // TAMPILKAN HALAMAN BUKU
        // =========================

        $this->load->view(
            'v_buku',
            $data
        );
    }


    // =========================
    // HALAMAN TAMBAH BUKU
    // =========================

    public function tambah()
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }


        // Ambil semua kategori

        $data['kategori'] = $this->db
            ->order_by(
                'id_kategori',
                'ASC'
            )
            ->get('kategori')
            ->result();


        // Tampilkan halaman tambah buku

        $this->load->view(
            'v_tambah_buku',
            $data
        );
    }


    // =========================
    // PROSES TAMBAH BUKU
    // =========================

    public function tambah_aksi()
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }


        // =========================
        // AMBIL DATA FORM
        // =========================

        $id_buku = $this->input->post('id_buku');


        $data = array(

            'id_buku' =>
                $id_buku,

            'judul' =>
                $this->input->post('judul'),

            'pengarang' =>
                $this->input->post('pengarang'),

            'tahun' =>
                $this->input->post('tahun'),

            'id_kategori' =>
                $this->input->post('id_kategori'),

            'stok' =>
                $this->input->post('stok')

        );


        // =========================
        // CEK ID BUKU
        // =========================

        $cek_buku = $this->db
            ->where(
                'id_buku',
                $id_buku
            )
            ->get('buku')
            ->row();


        // Kalau ID sudah ada

        if ($cek_buku) {

            $this->session->set_flashdata(
                'error',
                'ID Buku ' . $id_buku . ' sudah digunakan. Silakan gunakan ID Buku yang lain.'
            );

            redirect('buku/tambah');

            return;
        }


        // =========================
        // SIMPAN DATA BUKU
        // =========================

        $insert = $this->db->insert(
            'buku',
            $data
        );


        // =========================
        // HASIL SIMPAN
        // =========================

        if ($insert) {

            $this->session->set_flashdata(
                'success',
                'Buku berhasil ditambahkan!'
            );

            redirect('buku');

            return;

        } else {

            $this->session->set_flashdata(
                'error',
                'Buku gagal ditambahkan.'
            );

            redirect('buku/tambah');

            return;
        }
    }


    // =========================
    // HALAMAN EDIT BUKU
    // =========================

    public function edit($id)
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }


        // Ambil data buku

        $data['buku'] = $this->db
            ->where(
                'id_buku',
                $id
            )
            ->get('buku')
            ->row();


        // Kalau buku tidak ditemukan

        if (!$data['buku']) {

            redirect('buku');

            return;
        }


        // =========================
        // AMBIL DATA KATEGORI
        // =========================

        $data['kategori_list'] = $this->db
            ->order_by(
                'id_kategori',
                'ASC'
            )
            ->get('kategori')
            ->result();


        // =========================
        // TAMPILKAN HALAMAN EDIT
        // =========================

        $this->load->view(
            'v_edit_buku',
            $data
        );
    }


    // =========================
    // PROSES EDIT BUKU
    // =========================

    public function edit_aksi()
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }


        // =========================
        // AMBIL ID LAMA DAN ID BARU
        // =========================

        $id_lama = $this->input->post('id_buku');

        $id_baru = $this->input->post('id_buku_baru');


        // =========================
        // CEK ID BUKU BARU
        // =========================

        if ($id_lama != $id_baru) {

            $cek_id = $this->db
                ->where(
                    'id_buku',
                    $id_baru
                )
                ->get('buku')
                ->row();


            // Kalau ID baru sudah digunakan

            if ($cek_id) {

                $this->session->set_flashdata(
                    'error',
                    'ID Buku ' . $id_baru . ' sudah digunakan oleh buku lain!'
                );

                redirect(
                    'buku/edit/' . $id_lama
                );

                return;
            }
        }


        // =========================
        // DATA BUKU
        // =========================

        $data = array(

            'id_buku' =>
                $id_baru,

            'judul' =>
                $this->input->post('judul'),

            'pengarang' =>
                $this->input->post('pengarang'),

            'tahun' =>
                $this->input->post('tahun'),

            'id_kategori' =>
                $this->input->post('id_kategori'),

            'stok' =>
                $this->input->post('stok')

        );


        // =========================
        // UPDATE DATA
        // =========================

        $update = $this->db
            ->where(
                'id_buku',
                $id_lama
            )
            ->update(
                'buku',
                $data
            );


        // =========================
        // NOTIFIKASI
        // =========================

        if ($update) {

            $this->session->set_flashdata(
                'success',
                'Data buku berhasil diperbarui!'
            );

        } else {

            $this->session->set_flashdata(
                'error',
                'Data buku gagal diperbarui.'
            );
        }


        // =========================
        // KEMBALI KE DATA BUKU
        // =========================

        redirect('buku');
    }


    // =========================
    // HAPUS BUKU
    // =========================

    public function hapus($id)
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }


        // Hapus data buku

        $this->db
            ->where(
                'id_buku',
                $id
            )
            ->delete('buku');


        // Notifikasi

        $this->session->set_flashdata(
            'success',
            'Buku berhasil dihapus!'
        );


        // Kembali ke Data Buku

        redirect('buku');
    }
}