<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->database();
        $this->load->library('session');
    }

    public function index()
    {
        // Cek login
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('index.php/login');
        }

        // =========================
        // TOTAL
        // =========================

        $total_anggota = $this->db->count_all('anggota');

        $total_buku = $this->db->count_all('buku');

        $total_peminjaman = $this->db->count_all('peminjaman');

        $total_terlambat = $this->db
            ->where('keterangan','Terlambat')
            ->count_all_results('peminjaman');

        // =========================
        // PEMINJAMAN 3 HARI TERAKHIR
        // =========================

        $batas = date('Y-m-d',strtotime('-2 days'));

        $peminjaman_terbaru = $this->db
            ->select('
                peminjaman.*,
                anggota.nama,
                buku.judul AS judul_buku
            ')
            ->from('peminjaman')
            ->join('anggota','anggota.id_anggota=peminjaman.id_anggota')
            ->join('buku','buku.id_buku=peminjaman.id_buku')
            ->where('tanggal_pinjam >=',$batas)
            ->order_by('tanggal_pinjam','DESC')
            ->order_by('id_pinjam','DESC')
            ->limit(5)
            ->get()
            ->result();

        // =========================
        // KIRIM DATA KE VIEW
        // =========================

        $data=array(

            'total_anggota'=>$total_anggota,

            'total_buku'=>$total_buku,

            'total_peminjaman'=>$total_peminjaman,

            'total_terlambat'=>$total_terlambat,

            'peminjaman_terbaru'=>$peminjaman_terbaru

        );

        $this->load->view('v_dashboard',$data);
    }
}