<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peminjaman extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->database();
        $this->load->library('session');
        $this->load->model('M_peminjaman');
    }

    // =========================
    // HALAMAN DATA
    // =========================
    public function index()
    {
        if($this->session->userdata('status')!='admin_login'){
            redirect('login');
        }

        $data['peminjaman']=$this->M_peminjaman->get_all();

        $this->load->view('v_peminjaman',$data);
    }

    // =========================
    // HALAMAN TAMBAH
    // =========================
    public function tambah()
    {
        if($this->session->userdata('status')!='admin_login'){
            redirect('login');
        }

        $data['anggota']=$this->db
            ->order_by('nama','ASC')
            ->get('anggota')
            ->result();

        $data['buku']=$this->db
            ->order_by('judul','ASC')
            ->get('buku')
            ->result();

        $this->load->view('v_tambah_peminjaman',$data);
    }

    // =========================
    // PROSES TAMBAH
    // =========================
    public function tambah_aksi()
{
    $tanggal_pinjam=$this->input->post('tanggal_pinjam');

    $tanggal_jatuh_tempo=date(
        'Y-m-d',
        strtotime($tanggal_pinjam.' +5 days')
    );

    // ID otomatis PM001 dst
    $last=$this->db
        ->select('id_pinjam')
        ->order_by('id_pinjam','DESC')
        ->limit(1)
        ->get('peminjaman')
        ->row();

    if($last){
        $angka=(int)substr($last->id_pinjam,2)+1;
    }else{
        $angka=1;
    }

    $id_pinjam='PM'.str_pad($angka,3,'0',STR_PAD_LEFT);

    $id_buku=$this->input->post('id_buku');

    // CEK STOK
    $stok=$this->db
        ->where('id_buku',$id_buku)
        ->get('buku')
        ->row();

    if(!$stok || $stok->stok<=0){

        $this->session->set_flashdata(
            'error',
            'Stok buku habis.'
        );

        redirect('peminjaman/tambah');
        return;
    }

    $data=array(

        'id_pinjam'=>$id_pinjam,

        'id_buku'=>$id_buku,

        'id_anggota'=>$this->input->post('id_anggota'),

        'id_petugas'=>$this->session->userdata('id_petugas'),

        'tanggal_pinjam'=>$tanggal_pinjam,

        'tanggal_jatuh_tempo'=>$tanggal_jatuh_tempo,

        'tanggal_kembali'=>NULL,

        'keterangan'=>'Dipinjam'

    );

    $this->M_peminjaman->tambah($data);

    // Kurangi stok
    $this->M_peminjaman->kurangi_stok($id_buku);

    $this->session->set_flashdata(
        'success',
        'Peminjaman berhasil ditambahkan!'
    );

    redirect('peminjaman');
}
    // =========================
    // HALAMAN EDIT
    // =========================
    public function edit($id)
    {
        if($this->session->userdata('status')!='admin_login'){
            redirect('login');
        }

        $data['peminjaman']=$this->M_peminjaman->get_by_id($id);

        $data['anggota']=$this->db
            ->order_by('nama','ASC')
            ->get('anggota')
            ->result();

        $data['buku']=$this->db
            ->order_by('judul','ASC')
            ->get('buku')
            ->result();

        $this->load->view('v_edit_peminjaman',$data);
    }

    // =========================
    // PROSES EDIT
    // =========================
    public function edit_aksi()
{
    $id=$this->input->post('id_pinjam');

    $lama=$this->M_peminjaman->get_by_id($id);

    $tanggal_pinjam=$this->input->post('tanggal_pinjam');

    $tanggal_jatuh_tempo=date(
        'Y-m-d',
        strtotime($tanggal_pinjam.' +5 days')
    );

    $tanggal_kembali=$this->input->post('tanggal_kembali');

    $keterangan=$this->input->post('keterangan');

    // Kalau sudah isi tanggal kembali
    if(!empty($tanggal_kembali)){

        if(empty($this->input->post('keterangan'))){

            if(strtotime($tanggal_kembali)>
               strtotime($tanggal_jatuh_tempo)){

                $keterangan="Terlambat";

            }else{

                $keterangan="Tepat Waktu";

            }

        }

    }

    $data=array(

        'id_anggota'=>$this->input->post('id_anggota'),

        'id_buku'=>$this->input->post('id_buku'),

        'tanggal_pinjam'=>$tanggal_pinjam,

        'tanggal_jatuh_tempo'=>$tanggal_jatuh_tempo,

        'tanggal_kembali'=>$tanggal_kembali,

        'keterangan'=>$keterangan

    );

    $this->M_peminjaman->edit($id,$data);

    // Tambah stok kalau baru dikembalikan
    if(
        empty($lama->tanggal_kembali)
        &&
        !empty($tanggal_kembali)
    ){
        $this->M_peminjaman->tambah_stok($lama->id_buku);
    }

    // Kurangi lagi kalau dikembalikan dibatalin
    if(
        !empty($lama->tanggal_kembali)
        &&
        empty($tanggal_kembali)
    ){
        $this->M_peminjaman->kurangi_stok($lama->id_buku);
    }

    $this->session->set_flashdata(
        'success',
        'Data peminjaman berhasil diperbarui!'
    );

    redirect('peminjaman');
}

    // =========================
    // HAPUS
    // =========================
    public function hapus($id)
{
    $pinjam=$this->M_peminjaman->get_by_id($id);

    if(!$pinjam){

        redirect('peminjaman');

        return;
    }

    // Kalau masih dipinjam, stok dikembalikan
    if(empty($pinjam->tanggal_kembali)){

        $this->M_peminjaman->tambah_stok($pinjam->id_buku);

    }

    $this->M_peminjaman->hapus($id);

    $this->session->set_flashdata(
        'success',
        'Data peminjaman berhasil dihapus!'
    );

    redirect('peminjaman');
}
}