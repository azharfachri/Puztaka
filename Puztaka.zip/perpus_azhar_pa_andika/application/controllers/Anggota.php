<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Anggota extends CI_Controller
{


    public function __construct()
    {
        parent::__construct();

        $this->load->database();

        $this->load->library('session');
    }



    // =========================
    // HALAMAN DATA ANGGOTA
    // =========================

    public function index()
    {

        if ($this->session->userdata('status') != 'admin_login') {

            redirect('login');

        }


        $keyword = $this->input->get('keyword');

        $kelas = $this->input->get('kelas');


        $this->db->from('anggota');


        if (!empty($keyword)) {

            $this->db->group_start();

            $this->db->like('id_anggota', $keyword);

            $this->db->or_like('nama', $keyword);

            $this->db->or_like('kelas', $keyword);

            $this->db->group_end();

        }


        if (!empty($kelas)) {

            $this->db->where('kelas', $kelas);

        }


        $this->db->order_by(
            'id_anggota',
            'ASC'
        );


        $data['anggota'] = $this->db
            ->get()
            ->result();


        // =========================
        // DAFTAR KELAS
        // =========================

        $data['kelas_list'] = $this->db
            ->distinct()
            ->select('kelas')
            ->order_by(
                'kelas',
                'ASC'
            )
            ->get('anggota')
            ->result();


        $this->load->view(
            'v_anggota',
            $data
        );

    }



    // =========================
    // HALAMAN TAMBAH ANGGOTA
    // =========================

    public function tambah()
    {

        if ($this->session->userdata('status') != 'admin_login') {

            redirect('login');

        }


        $this->load->view(
            'v_tambah_anggota'
        );

    }



    // =========================
    // PROSES TAMBAH ANGGOTA
    // =========================

    public function tambah_aksi()
    {

        if ($this->session->userdata('status') != 'admin_login') {

            redirect('login');

        }


        $data = array(

            'id_anggota' =>
                $this->input->post('id_anggota'),

            'nama' =>
                $this->input->post('nama'),

            'kelas' =>
                $this->input->post('kelas'),

            'alamat' =>
                $this->input->post('alamat')

        );


        $this->db->insert(
            'anggota',
            $data
        );


        $this->session->set_flashdata(
            'success',
            'Anggota berhasil ditambahkan!'
        );


        redirect('anggota');

    }



    // =========================
    // HAPUS ANGGOTA
    // =========================

    public function hapus($id)
    {

        if ($this->session->userdata('status') != 'admin_login') {

            redirect('login');

        }


        $this->db->where(
            'id_anggota',
            $id
        );


        if ($this->db->delete('anggota')) {


            $this->session->set_flashdata(
                'success',
                'Anggota berhasil dihapus!'
            );


        } else {


            $this->session->set_flashdata(
                'error',
                'Anggota gagal dihapus.'
            );


        }


        redirect('anggota');

    }



    // =========================
    // HALAMAN EDIT ANGGOTA
    // =========================

    public function edit($id)
    {

        if ($this->session->userdata('status') != 'admin_login') {

            redirect('login');

        }


        $data['anggota'] = $this->db
            ->where(
                'id_anggota',
                $id
            )
            ->get('anggota')
            ->row();


        if (!$data['anggota']) {

            redirect('anggota');

        }


        $this->load->view(
            'v_edit_anggota',
            $data
        );

    }



    // =========================
    // PROSES EDIT ANGGOTA
    // =========================

    public function edit_aksi()
    {

        if ($this->session->userdata('status') != 'admin_login') {

            redirect('login');

        }


        // =========================
        // ID LAMA
        // =========================

        $id_lama = $this->input->post(
            'id_anggota'
        );


        // =========================
        // ID BARU
        // =========================

        $id_baru = $this->input->post(
            'id_anggota_baru'
        );


        // =========================
        // DATA BARU
        // =========================

        $data = array(

            'id_anggota' =>
                $id_baru,

            'nama' =>
                $this->input->post('nama'),

            'kelas' =>
                $this->input->post('kelas'),

            'alamat' =>
                $this->input->post('alamat')

        );


        // =========================
        // CEK ID BARU
        // =========================
        // Kalau ID baru berbeda dari ID lama,
        // pastikan ID tersebut belum digunakan.

        if ($id_baru != $id_lama) {


            $cek = $this->db
                ->where(
                    'id_anggota',
                    $id_baru
                )
                ->get('anggota')
                ->row();


            if ($cek) {


                $this->session->set_flashdata(
                    'error',
                    'ID Anggota ' . $id_baru . ' sudah digunakan. Silakan gunakan ID Anggota yang lain.'
                );


                redirect(
                    'anggota/edit/' . $id_lama
                );


                return;

            }

        }


        // =========================
        // UPDATE DATA
        // =========================

        $update = $this->db
            ->where(
                'id_anggota',
                $id_lama
            )
            ->update(
                'anggota',
                $data
            );


        // =========================
        // NOTIFIKASI
        // =========================

        if ($update) {


            $this->session->set_flashdata(
                'success',
                'Data anggota berhasil diperbarui!'
            );


        } else {


            $this->session->set_flashdata(
                'error',
                'Data anggota gagal diperbarui.'
            );


        }


        redirect('anggota');

    }

}