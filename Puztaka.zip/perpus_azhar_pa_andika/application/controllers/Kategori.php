<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        $this->load->database();
        $this->load->library('session');
    }


    // =========================
    // HALAMAN DATA KATEGORI
    // =========================
    public function index()
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }

        $keyword = $this->input->get('keyword');

        $this->db->from('kategori');

        if (!empty($keyword)) {

            $this->db->group_start();

            $this->db->like(
                'id_kategori',
                $keyword
            );

            $this->db->or_like(
                'nama_kategori',
                $keyword
            );

            $this->db->group_end();
        }

        $this->db->order_by(
            'id_kategori',
            'ASC'
        );

        $data['kategori'] = $this->db
            ->get()
            ->result();

        $this->load->view(
            'v_kategori',
            $data
        );
    }


    // =========================
    // HALAMAN TAMBAH
    // =========================
    public function tambah()
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }

        $this->load->view(
            'v_tambah_kategori'
        );
    }


    // =========================
    // PROSES TAMBAH
    // =========================
    public function tambah_aksi()
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }

        $id = $this->input->post(
            'id_kategori'
        );

        $nama = $this->input->post(
            'nama_kategori'
        );


        // =========================
        // CEK ID KATEGORI
        // =========================

        $cek = $this->db
            ->where(
                'id_kategori',
                $id
            )
            ->get('kategori')
            ->row();


        if ($cek) {

            $this->session->set_flashdata(
                'error',
                'ID kategori sudah digunakan!'
            );

            redirect(
                'kategori/tambah'
            );

            return;
        }


        // =========================
        // DATA KATEGORI
        // =========================

        $data = array(

            'id_kategori' =>
                $id,

            'nama_kategori' =>
                $nama

        );


        // =========================
        // SIMPAN
        // =========================

        $this->db->insert(
            'kategori',
            $data
        );


        $this->session->set_flashdata(
            'success',
            'Kategori berhasil ditambahkan!'
        );


        redirect(
            'kategori'
        );
    }


    // =========================
    // HALAMAN EDIT
    // =========================
    public function edit($id)
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }


        // =========================
        // AMBIL DATA KATEGORI
        // =========================

        $data['kategori'] = $this->db
            ->where(
                'id_kategori',
                $id
            )
            ->get('kategori')
            ->row();


        // =========================
        // JIKA TIDAK ADA
        // =========================

        if (!$data['kategori']) {

            redirect(
                'kategori'
            );

            return;
        }


        // =========================
        // AMBIL DAFTAR KATEGORI
        // =========================
        // Tetap dikirim agar tidak
        // menghilangkan fungsi lain
        // dari halaman sebelumnya.

        $data['kategori_list'] = $this->db
            ->order_by(
                'id_kategori',
                'ASC'
            )
            ->get('kategori')
            ->result();


        // =========================
        // TAMPILKAN HALAMAN EDIT
        // =========================

        $this->load->view(
            'v_edit_kategori',
            $data
        );
    }


    // =========================
    // PROSES EDIT
    // =========================
    public function edit_aksi()
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }


        // =========================
        // ID LAMA
        // =========================

        $id_lama = $this->input->post(
            'id_kategori'
        );


        // =========================
        // ID BARU
        // =========================

        $id_baru = $this->input->post(
            'id_kategori_baru'
        );


        // =========================
        // NAMA BARU
        // =========================

        $nama = $this->input->post(
            'nama_kategori'
        );


        // =========================
        // CEK ID BARU
        // =========================
        // Jangan sampai ID baru
        // sudah digunakan kategori lain.

        if ($id_baru != $id_lama) {

            $cek = $this->db
                ->where(
                    'id_kategori',
                    $id_baru
                )
                ->get('kategori')
                ->row();


            if ($cek) {

                $this->session->set_flashdata(
                    'error',
                    'ID kategori ' . $id_baru . ' sudah digunakan!'
                );

                redirect(
                    'kategori/edit/' . $id_lama
                );

                return;
            }
        }


        // =========================
        // DATA YANG DIUPDATE
        // =========================

        $data = array(

            'id_kategori' =>
                $id_baru,

            'nama_kategori' =>
                $nama

        );


        // =========================
        // UPDATE
        // =========================

        $update = $this->db
            ->where(
                'id_kategori',
                $id_lama
            )
            ->update(
                'kategori',
                $data
            );


        // =========================
        // HASIL UPDATE
        // =========================

        if ($update) {

            $this->session->set_flashdata(
                'success',
                'Data kategori berhasil diperbarui!'
            );

        } else {

            $this->session->set_flashdata(
                'error',
                'Data kategori gagal diperbarui.'
            );
        }


        // =========================
        // KEMBALI
        // =========================

        redirect(
            'kategori'
        );
    }


    // =========================
    // HAPUS
    // =========================
    public function hapus($id)
    {
        if ($this->session->userdata('status') != 'admin_login') {
            redirect('login');
        }


        // =========================
        // CEK APAKAH DIGUNAKAN BUKU
        // =========================

        $cek = $this->db
            ->where(
                'id_kategori',
                $id
            )
            ->get('buku')
            ->num_rows();


        if ($cek > 0) {

            $this->session->set_flashdata(
                'error',
                'Kategori tidak dapat dihapus karena masih digunakan oleh data buku!'
            );

            redirect(
                'kategori'
            );

            return;
        }


        // =========================
        // HAPUS KATEGORI
        // =========================

        $this->db
            ->where(
                'id_kategori',
                $id
            )
            ->delete(
                'kategori'
            );


        // =========================
        // NOTIFIKASI
        // =========================

        $this->session->set_flashdata(
            'success',
            'Kategori berhasil dihapus!'
        );


        redirect(
            'kategori'
        );
    }
}