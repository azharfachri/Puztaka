<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // Model
        $this->load->model('M_data', 'm_data');

        // Library
        $this->load->library('session');
        $this->load->library('form_validation');
    }


    // ==========================================
    // HALAMAN LOGIN
    // ==========================================

    public function index()
    {
        // Kalau sudah login sebagai admin,
        // langsung arahkan ke dashboard
        if ($this->session->userdata('status') == 'admin_login') {

            redirect('dashboard');

        }

        $this->load->view('v_login');
    }


    // ==========================================
    // PROSES LOGIN
    // ==========================================

    public function login_aksi()
    {

        // Ambil data dari form
        $username = $this->input->post('username');
        $password = $this->input->post('password');


        // Validasi form
        $this->form_validation->set_rules(
            'username',
            'Username',
            'required'
        );

        $this->form_validation->set_rules(
            'password',
            'Password',
            'required'
        );


        // Kalau validasi gagal
        if ($this->form_validation->run() == false) {

            $this->load->view('v_login');

            return;
        }


        // ==========================================
        // CEK USERNAME DAN PASSWORD
        // ==========================================

        $where = array(

            'username' => $username,

            'password' => md5($password)

        );


        $cek = $this->m_data
            ->cek_login($where)
            ->num_rows();


        // ==========================================
        // LOGIN BERHASIL
        // ==========================================

        if ($cek > 0) {

            $data = $this->m_data
                ->cek_login($where)
                ->row();


            // Data session
            $data_session = array(

                'id_petugas' =>
                    $data->id_petugas,

                'nama_petugas' =>
                    $data->nama_petugas,

                'username' =>
                    $data->username,

                'status' =>
                    'admin_login'

            );


            // Simpan session
            $this->session->set_userdata(
                $data_session
            );


            // Masuk dashboard
            redirect('dashboard');

        }


        // ==========================================
        // LOGIN GAGAL
        // ==========================================

        else {

            $this->session->set_flashdata(
                'error',
                'Username atau password salah.'
            );

            redirect('login');

        }

    }


    // ==========================================
    // LOGOUT
    // ==========================================

    public function logout()
    {

        // Hapus seluruh session
        $this->session->sess_destroy();


        // Kembali ke halaman login
        redirect('login');

    }

}