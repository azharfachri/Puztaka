const search = document.getElementById("searchBuku");
const filter = document.getElementById("filterKategori");
const reset = document.getElementById("resetFilter");

function filterBuku() {

    const keyword = search.value.toLowerCase().trim();
    const kategori = filter.value.toLowerCase();

    document.querySelectorAll("#tabelBuku tbody tr").forEach(row => {

        const id = row.dataset.id || "";
        const judul = row.dataset.judul || "";
        const pengarang = row.dataset.pengarang || "";
        const kategoriId = row.dataset.kategori || "";
        const kategoriNama = row.dataset.kategorinama || "";

        const cocokKeyword =
            id.includes(keyword) ||
            judul.includes(keyword) ||
            pengarang.includes(keyword) ||
            kategoriId.includes(keyword) ||
            kategoriNama.includes(keyword);

        const cocokKategori =
            kategori === "" ||
            kategoriId === kategori;

        row.style.display =
            cocokKeyword && cocokKategori
                ? ""
                : "none";

    });

}


search.addEventListener("input", filterBuku);

filter.addEventListener("change", filterBuku);


reset.addEventListener("click", () => {

    search.value = "";

    filter.value = "";

    filterBuku();

});