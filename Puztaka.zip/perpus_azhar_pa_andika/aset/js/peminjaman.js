// ===============================
// SEARCH + FILTER PEMINJAMAN
// ===============================

const search = document.getElementById("searchPinjam");
const filter = document.getElementById("filterStatus");

function filterTable() {

    const keyword = search.value.toLowerCase().trim();
    const status = filter.value.toLowerCase();

    document.querySelectorAll(".pinjam-row").forEach(row => {

        const idPinjam = row.dataset.id || "";
        const idAnggota = row.dataset.idanggota || "";
        const anggota = row.dataset.anggota || "";
        const buku = row.dataset.buku || "";
        const stat = row.dataset.status || "";

        const cocokKeyword =
            idPinjam.includes(keyword) ||
            idAnggota.includes(keyword) ||
            anggota.includes(keyword) ||
            buku.includes(keyword);

        const cocokStatus = status === "" || stat === status;

        row.style.display = (cocokKeyword && cocokStatus) ? "" : "none";
    });

}

search.addEventListener("input", filterTable);
filter.addEventListener("change", filterTable);

// ===============================
// SWEET ALERT HAPUS
// ===============================

document.querySelectorAll(".btn-hapus").forEach(btn => {

    btn.addEventListener("click", function(e){

        e.preventDefault();

        const url = this.href;

        Swal.fire({
            title:"Hapus peminjaman?",
            text:"Data yang dihapus tidak dapat dikembalikan.",
            icon:"warning",
            showCancelButton:true,
            confirmButtonColor:"#ef4444",
            cancelButtonColor:"#23308b",
            confirmButtonText:"Ya, Hapus",
            cancelButtonText:"Batal"

        }).then((result)=>{

            if(result.isConfirmed){

                window.location.href=url;

            }

        });

    });

});