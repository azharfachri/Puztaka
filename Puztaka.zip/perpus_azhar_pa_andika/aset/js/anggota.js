const searchInput = document.getElementById("searchNama");
const filterKelas = document.getElementById("filterKelas");
const btnFilter = document.getElementById("btnFilter");
const resetFilter = document.getElementById("resetFilter");


/* =========================================
   FUNGSI FILTER DATA ANGGOTA
========================================= */

function filterAnggota() {

    const keyword = searchInput.value
        .toLowerCase()
        .trim();

    const kelas = filterKelas.value
        .toLowerCase()
        .trim();


    const rows = document.querySelectorAll(
        "#tabelAnggota tbody tr"
    );


    rows.forEach(function(row) {

        const id = row.dataset.id || "";

        const nama = row.dataset.nama || "";

        const kelasData = row.dataset.kelas || "";


        /*
         * PENCARIAN BISA BERDASARKAN:
         * 1. ID Anggota
         * 2. Nama
         * 3. Kelas
         */

        const cocokKeyword =
            id.includes(keyword) ||
            nama.includes(keyword) ||
            kelasData.includes(keyword);


        /*
         * FILTER KELAS
         */

        const cocokKelas =
            kelas === "" ||
            kelasData === kelas;


        /*
         * TAMPILKAN / SEMBUNYIKAN DATA
         */

        if (cocokKeyword && cocokKelas) {

            row.style.display = "";

        } else {

            row.style.display = "none";

        }

    });

}


/* =========================================
   PENCARIAN LANGSUNG SAAT MENGETIK
========================================= */

searchInput.addEventListener(
    "input",
    filterAnggota
);


/* =========================================
   FILTER KELAS
========================================= */

filterKelas.addEventListener(
    "change",
    filterAnggota
);


/* =========================================
   TOMBOL CARI
========================================= */

btnFilter.addEventListener(
    "click",
    filterAnggota
);


/* =========================================
   TOMBOL RESET
========================================= */

resetFilter.addEventListener(
    "click",
    function() {

        searchInput.value = "";

        filterKelas.value = "";

        filterAnggota();

    }
);