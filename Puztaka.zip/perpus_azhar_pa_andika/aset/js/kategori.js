document.addEventListener("DOMContentLoaded", function(){

    const input = document.getElementById("keywordKategori");
    const clear = document.getElementById("clearSearch");

    if(input){

        const rows = document.querySelectorAll(".kategori-row");
        const empty = document.getElementById("searchEmpty");

        function cari(){

            const keyword = input.value.toLowerCase().trim();
            let total = 0;

            rows.forEach(row=>{

                const id = row.dataset.id;
                const nama = row.dataset.nama;

                if(id.includes(keyword) || nama.includes(keyword)){
                    row.style.display="";
                    total++;
                }else{
                    row.style.display="none";
                }

            });

            if(empty){
                empty.style.display=(keyword!=="" && total===0)?"":"none";
            }

            if(clear){
                clear.style.display=keyword!==""?"flex":"none";
            }

        }

        input.addEventListener("input",cari);

        if(clear){

            clear.addEventListener("click",function(){

                input.value="";
                cari();
                input.focus();

            });

        }

        cari();
    }


    // SweetAlert Konfirmasi Hapus

    document.querySelectorAll(".btn-hapus").forEach(btn=>{

        btn.addEventListener("click",function(e){

            e.preventDefault();

            const url=this.href;

            Swal.fire({
                title:"Hapus kategori?",
                text:"Data yang dihapus tidak dapat dikembalikan.",
                icon:"warning",
                showCancelButton:true,
                confirmButtonColor:"#ff6b4a",
                cancelButtonColor:"#6b7280",
                confirmButtonText:"Ya, Hapus",
                cancelButtonText:"Batal"
            }).then((result)=>{

                if(result.isConfirmed){
                    window.location.href=url;
                }

            });

        });

    });

});